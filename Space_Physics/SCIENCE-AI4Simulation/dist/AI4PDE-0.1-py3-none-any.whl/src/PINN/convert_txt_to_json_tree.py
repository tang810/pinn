import json
import re

def extract_description(comment):
    """
    从注释中提取描述信息
    """
    # 移除 # 符号并去除首尾空白
    return comment.lstrip('# ').strip() if comment else "No description available"

def parse_directory_structure(text):
    """
    Parse the directory structure text into a structured JSON format.
    
    Args:
        text (str): Raw directory structure text
    
    Returns:
        dict: Structured JSON representation of the directory
    """
    # 按行分割
    lines = text.split('\n')
    
    # 初始化目录结构字典
    directory_structure = {
        "modules": []
    }
    
    # 当前模块和子模块追踪
    current_module = None
    current_submodule = None
    current_subsubmodule = None
    
    # 正则表达式用于匹配路径和注释
    path_pattern = re.compile(r'^(│\s*)*[├└]─\s*(.+?)(?:\s*#\s*(.+))?$')
    
    for line in lines:
        # 跳过空行和根目录
        if not line.strip() or line.startswith('AI4PDE'):
            continue
        
        # 匹配路径
        match = path_pattern.match(line)
        if not match:
            continue
        
        # 提取路径和注释
        path_parts = match.group(2).split('/')
        comment = match.group(3)
        description = extract_description(comment) if comment else "No description available"
        
        # 计算缩进级别
        indent_level = (len(match.group(0)) - len(match.group(0).lstrip('│ '))) // 2
        
        # 处理不同缩进级别
        if indent_level == 0:  # 模块级别
            module_name = path_parts[0]
            module_entry = {
                "name": module_name,
                "path": f"AI4PDE/{module_name}",
                "description": description,
                "submodules": []
            }
            directory_structure["modules"].append(module_entry)
            current_module = module_entry
            current_submodule = None
            current_subsubmodule = None
        
        elif indent_level == 1:  # 子模块级别
            if current_module is None:
                continue
            
            submodule_name = path_parts[0]
            full_submodule_path = f"{current_module['path']}/{submodule_name}"
            
            submodule_entry = {
                "name": submodule_name,
                "path": full_submodule_path,
                "description": description,
                "files": [],
                "submodules": []
            }
            current_module["submodules"].append(submodule_entry)
            current_submodule = submodule_entry
            current_subsubmodule = None
        
        elif indent_level == 2:  # 子子模块级别
            if current_submodule is None:
                continue
            
            # 检查是否为文件或子子模块
            if len(path_parts[0].split('.')) > 1:  # 如果包含文件扩展名，则为文件
                file_name = path_parts[0]
                full_file_path = f"{current_submodule['path']}/{file_name}"
                
                file_entry = {
                    "name": file_name,
                    "path": full_file_path,
                    "description": description
                }
                current_submodule["files"].append(file_entry)
            else:  # 否则为子子模块
                subsubmodule_name = path_parts[0]
                full_subsubmodule_path = f"{current_submodule['path']}/{subsubmodule_name}"
                
                subsubmodule_entry = {
                    "name": subsubmodule_name,
                    "path": full_subsubmodule_path,
                    "description": description,
                    "files": []
                }
                current_submodule["submodules"].append(subsubmodule_entry)
                current_subsubmodule = subsubmodule_entry
        
        elif indent_level == 3:  # 文件级别
            if current_subsubmodule is None and current_submodule is None:
                continue
            
            file_name = path_parts[0]
            if current_subsubmodule:
                full_file_path = f"{current_subsubmodule['path']}/{file_name}"
                file_entry = {
                    "name": file_name,
                    "path": full_file_path,
                    "description": description
                }
                current_subsubmodule["files"].append(file_entry)
            elif current_submodule:
                full_file_path = f"{current_submodule['path']}/{file_name}"
                file_entry = {
                    "name": file_name,
                    "path": full_file_path,
                    "description": description
                }
                current_submodule["files"].append(file_entry)
    
    return directory_structure

# 读取文件内容
with open('/home/suser/se42/ximu_science/responsible_programming/src/AI4PDE/TREE.txt', 'r', encoding='utf-8') as f:
    directory_text = f.read()

# 解析目录结构
parsed_structure = parse_directory_structure(directory_text)

# 输出 JSON
print(json.dumps(parsed_structure, indent=2, ensure_ascii=False))

# 保存 JSON 文件
with open('ai4pde_structure.json', 'w', encoding='utf-8') as f:
    json.dump(parsed_structure, f, indent=2, ensure_ascii=False)

print("\nJSON file 'ai4pde_structure.json' has been created.")