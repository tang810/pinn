import os
import torch
import scipy.io
import numpy as np
from net import FCNet
from net import ChebyKAN
from net import ChebyKAN_1
from tqdm.auto import tqdm
from typing import Dict, List, Set, Optional, Union, Callable
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

def tonp(tensor): #将torch张量转换为numpy数组
    """ Torch to Numpy """
    if isinstance(tensor, torch.Tensor):   #将torch.Tensor从GPU转移到CPU上
        return tensor.detach().cpu().numpy()
    elif isinstance(tensor, np.ndarray):
        return tensor
    else:
        raise TypeError('Unknown type of input, expected torch.Tensor or '\
            'np.ndarray, but got {}'.format(type(input)))

class PysicsInformedNeuralNetwork:
    # Initialize the class
    def __init__(self,
                 opt=None,
                 nu_0 = 1.46073e-5,
                 U_0 = 69.444,
                 rho_0 = 1.225,
                 L_0 = 1.0,
                 layers=6,
                 layers_1=6,
                 hidden_size=80,
                 hidden_size_1=20,
                 N_f = 40000,
                 alpha_evm=0.03,
                 learning_rate=0.001,
                 weight_decay=0.9,
                 outlet_weight=1,
                 bc_weight=1,
                 eq_weight=1,
                 ic_weight=1,
                 # num_ins=2,
                 # num_outs=3,
                 # num_outs_1=1,
                 supervised_data_weight=1,
                 net_params=None,
                 net_params_1=None,
                 checkpoint_freq=2000,
                 checkpoint_path='./checkpoint/'):

        self.nu_0 = nu_0
        self.U_0 = U_0
        self.rho_0 = rho_0
        self.L_0 = L_0

        # SST constants
        self.sigma_k1 = 0.85
        self.sigma_w1 = 0.5
        self.beta_1 = 0.075

        self.sigma_k2 = 1.00
        self.sigma_w2 = 0.865
        self.beta_2 = 0.0828

        self.beta_star = 0.09
        self.a1 = 0.31

        self.alpha_1 = 5.0/9.0
        self.alpha_2 = 0.44

        self.evm = None
        self.vis_t0 = 5.0*self.nu_0

        self.layers = layers
        self.layers_1 = layers_1
        self.hidden_size = hidden_size
        self.hidden_size_1 = hidden_size_1
        self.N_f = N_f

        self.checkpoint_freq = checkpoint_freq
        self.checkpoint_path = checkpoint_path

        self.alpha_evm = alpha_evm
        self.alpha_b = bc_weight
        self.alpha_e = eq_weight
        self.alpha_i = ic_weight
        self.alpha_o = outlet_weight
        self.alpha_s = supervised_data_weight
        self.loss_i = self.loss_o = self.loss_b = self.loss_e = self.loss_s = 0.0
        
        self.L2_u = []
        self.L2_v = []

        # initialize NN
        self.net = ChebyKAN().to(device)

        if net_params:
            load_params = torch.load(net_params)
            self.net.load_state_dict(load_params)
        self.net_1 = ChebyKAN_1().to(device)
        if net_params_1:
            load_params_1 = torch.load(net_params_1)
            self.net_1.load_state_dict(load_params_1)

        # self.net = self.initialize_NN(
        #         num_ins=num_ins, num_outs=num_outs, num_layers=layers, hidden_size=hidden_size).to(device)
        # self.net_1 = self.initialize_NN(
        #         num_ins=num_ins, num_outs=num_outs_1, num_layers=layers_1, hidden_size=hidden_size_1).to(device)
        if net_params:
            load_params = torch.load(net_params)
            self.net.load_state_dict(load_params)

        if net_params_1:
            load_params_1 = torch.load(net_params_1)
            self.net_1.load_state_dict(load_params_1)

        self.opt = torch.optim.Adam(
            list(self.net.parameters())+list(self.net_1.parameters()),
            lr=learning_rate,
            weight_decay=0.0) if not opt else opt

    def init_vis_t(self):
        (_,_,_,e) = self.neural_net_u(self.x_f, self.y_f)
        self.vis_t_minus  = self.alpha_evm*torch.abs(e).detach().cpu().numpy()

    def set_boundary_data(self, X=None, time=False):
        # boundary training data | u, v, t, x, y
        requires_grad = False
        self.x_b = torch.tensor(X[0], requires_grad=requires_grad).float().to(device)
        self.y_b = torch.tensor(X[1], requires_grad=requires_grad).float().to(device)
        self.z_b = torch.tensor(X[2], requires_grad=requires_grad).float().to(device)
        self.u_b = torch.tensor(X[3], requires_grad=requires_grad).float().to(device)
        self.v_b = torch.tensor(X[4], requires_grad=requires_grad).float().to(device)
        self.w_b = torch.tensor(X[5], requires_grad=requires_grad).float().to(device)
        self.p_b = torch.tensor(X[6], requires_grad=requires_grad).float().to(device)
        if time:
            self.t_b = torch.tensor(X[7], requires_grad=requires_grad).float().to(device)

    def set_eq_training_data(self,
                             X=None,
                             time=False):
        requires_grad = True
        self.x_f = torch.tensor(X[0], requires_grad=requires_grad).float().to(device)
        self.y_f = torch.tensor(X[1], requires_grad=requires_grad).float().to(device)
        self.z_f = torch.tensor(X[2], requires_grad=requires_grad).float().to(device)
        if time:
            self.t_f = torch.tensor(X[3], requires_grad=requires_grad).float().to(device)

        self.init_vis_t()

    def set_testing_data(self,
                         x_star=None,
                         y_star=None,
                         z_star=None,
                         u_star=None,
                         v_star=None,
                         w_star=None,
                         p_star=None,
                         time=False):
        requires_grad = False
        self.x_star = torch.tensor(x_star, requires_grad=requires_grad).float().to(device)
        self.y_star = torch.tensor(y_star, requires_grad=requires_grad).float().to(device)
        self.z_star = torch.tensor(z_star, requires_grad=requires_grad).float().to(device)
        self.u_star = torch.tensor(u_star, requires_grad=requires_grad).float().to(device)
        self.v_star = torch.tensor(v_star, requires_grad=requires_grad).float().to(device)
        self.w_star = torch.tensor(w_star, requires_grad=requires_grad).float().to(device)
        self.p_star = torch.tensor(p_star, requires_grad=requires_grad).float().to(device)


    def set_optimizers(self, opt):
        self.opt = opt

    def set_alpha_evm(self, alpha):
        self.alpha_evm = alpha

    # def initialize_NN(self,
    #                   num_ins=2,
    #                   num_outs=4,
    #                   num_layers=10,
    #                   hidden_size=50):
    #     return FCNet(num_ins=num_ins,
    #                  num_outs=num_outs,
    #                  num_layers=num_layers,
    #                  hidden_size=hidden_size,
    #                  activation=torch.nn.Tanh)

    def set_eq_training_func(self, train_data_func):
        self.train_data_func = train_data_func

    def neural_net_u(self, x, y, z):
        X = torch.cat((x, y, z), dim=1)
        uvp = self.net(X)
        ee = self.net_1(X)
        u = uvp[:, 0:1]
        v = uvp[:, 1:2]
        w = uvp[:, 2:3]
        p = uvp[:, 3:4]
        k =  ee[:, 0:1]
        o =  ee[:, 1:2]
        return u, v, w, p, k, o

    def neural_net_equations(self, x, y, z):
        X = torch.cat((x, y, z), dim=1)
        uvp = self.net(X)
        ee = self.net_1(X)

        u = uvp[:, 0:1]
        v = uvp[:, 1:2]
        w = uvp[:, 2:3]
        p = uvp[:, 3:4]
        k = ee[:, 0:1]
        o = ee[:, 1:2]

        self.evm = e

        u_x, u_y, u_z = self.autograd(u, [x,y,z])
        u_xx = self.autograd(u_x, [x])[0]
        u_yy = self.autograd(u_y, [y])[0]
        u_zz = self.autograd(u_z, [z])[0]

        v_x, v_y, v_z = self.autograd(v, [x,y,z])
        v_xx = self.autograd(v_x, [x])[0]
        v_yy = self.autograd(v_y, [y])[0]
        v_zz = self.autograd(v_z, [z])[0]

        w_x, w_y, w_z = self.autograd(w, [x,y,z])
        w_xx = self.autograd(w_x, [x])[0]
        w_yy = self.autograd(w_y, [y])[0]
        w_zz = self.autograd(w_z, [z])[0]

        p_x, p_y, p_z = self.autograd(p, [x,y,z])

        k_x, k_y, k_z = self.autograd(k, [x,y,z])
        k_xx = self.autograd(k_x, [x])[0]
        k_yy = self.autograd(k_y, [y])[0]
        k_zz = self.autograd(k_z, [z])[0]

        o_x, o_y, o_z = self.autograd(o, [x,y,z])
        o_xx = self.autograd(o_x, [x])[0]
        o_yy = self.autograd(o_y, [y])[0]
        o_zz = self.autograd(o_z, [z])[0]
      
        self.nu_u_old = torch.tensor(self.nu_u).float().to(device)

        self.nu_k_old = torch.tensor(self.nu_k).float().to(device)

        self.nu_o_old = torch.tensor(self.nu_o).float().to(device)

        self.P1_old = torch.tensor(self.P1).float().to(device)

        self.P2_old = torch.tensor(self.P2).float().to(device)

        self.P3_old = torch.tensor(self.P3).float().to(device)

        self.P4_old = torch.tensor(self.P4).float().to(device)

        self.P5_old = torch.tensor(self.P5).float().to(device)


        nu_u_x, nu_u_y, nu_u_z = self.autograd(self.nu_u_old, [x,y,z])

        nu_k_x, nu_k_y, nu_k_z = self.autograd(self.nu_k_old, [x,y,z])

        nu_o_x, nu_o_y, nu_o_z = self.autograd(self.nu_o_old, [x,y,z])

        
        # NS
        eq1 = (u*u_x + v*u_y + w*u_z) + p_x/self.rho_0 - (self.nu_0+self.nu_u_old)*(u_xx + u_yy + u_zz) \
                 - (2.0*nu_u_x*u_x+nu_u_y*(u_y+v_x)+nu_u_z*(u_z+w_x))

        eq2 = (u*v_x + v*v_y + w*v_z) + p_y/self.rho_0 - (self.nu_0+self.nu_u_old)*(v_xx + v_yy + v_zz) \
                 - (nu_u_x*(v_x+u_y) + 2.0*nu_u_y*v_y + nu_u_z*(v_z+w_x))

        eq3 = (u*w_x + v*w_y + w*w_z) + p_z/self.rho_0 - (self.nu_0+self.nu_u_old)*(w_xx + w_yy + w_zz) \
                 - (nu_u_x*(w_x+u_z) + nu_u_y*(w_y + v_z) + 2.0*nu_u_z*w_z)

        eq4 = u_x + v_y + w_z

        eq5 = (u*k_x + v*k_y + w*k_z) - (self.nu_0+self.nu_k_old)*(k_xx + k_yy + k_zz) \
              - (2.0*nu_k_x*k_x+nu_k_y*(k_y+k_x)+nu_k_z*(k_z+k_x)) - self.P1_old + self.P2_old

        eq6 = (u*o_x + v*o_y + w*o_z) - (self.nu_0+self.nu_o_old)*(o_xx + o_yy + o_zz) \
                - (2.0*nu_o_x*o_x+nu_o_y*(o_y+o_x)+nu_o_z*(o_z+o_x)) - self.P3_old + self.P4_old - self.P5_old

        self.inv_o = np.maximum(np.minimum((1.0/o).detach().cpu().numpy(),1e7),-1e7)

        self.CD_ko =np.max(2.0*self.rho_0*self.sigma_w2*self.inv_o*((k_x*o_x+k_y*o_y+k_z*o_z)).detach().cpu().numpy(),1e-10)

        self.arg1_1 = torch.sqrt(k).detach().cpu().numpy()/self.beta_star*self.inv_o*self.inv_d

        self.arg1_2 = 500.0*self.nu_0*self.inv_d*self.inv_d*inv_o

        self.arg1_3 = k.detach().cpu().numpy()*4.0*self.rho_0*self.sigma_w2/self.CD_ko*self.inv_d*self.inv_d

        self.arg1 = np.minimum(np.maximum(self.arg1_1, self.arg1_2),self.arg1_3)

        self.arg2 = np.maximum(2.0*self.arg1_1, self.arg1_2) 

        self.F1 = np.tanh(np.power(arg1,4.0))

        self.F2 = np.tanh(np.power(arg2,2.0))

        self.S = torch.sqrt(2*(u_x*u_x+v_y*v_y+w_z*w_z+2.0*(v_x*u_y+w_x*u_z+v_z*w_y))).detach().cpu().numpy()

        self.nu_u = self.a1*k.detach().cpu().numpy()/np.maximum(self.a1*o.detach().cpu().numpy(),self.S*self.F2)

        self.sigma_k = self.F1*self.sigma_k1+(1.0-self.F1)*self.sigma_k2

        self.sigma_o = self.F1*self.sigma_o1+(1.0-self.F1)*self.sigma_o2
        
        self.P_2 = self.beta_star*(o*k).detach().cpu().numpy()

        self.P_1 = np.minimum(self.nu_t*(u_x*u_x+v_y*v_y+w_z*w_z+2.0*(v_x*u_y+w_x*u_z+v_z*w_y) + \
                              u_x*u_x+u_y*u_y+u_z*u_z+v_x*v_x+v_y*v_y+v_z*v_z+w_x*w_x+w_y*w_y+w_z*w_z).detach().cpu().numpy(), \
                              10.0*self.P_2)

        

        self.alpha = self.F1*self.alpha_1+(1.0-self.F1)*self.alpha_2

        self.beta = self.F1*self.beta_1+(1.0-self.F1)*self.beta_2

        self.P_3 = self.alpha * self.S*self.S

        self.P_4 = self.beta * (o*o).detach().cpu().numpy()

        self.P_5 = 2.0*(1.0-self.F1)*self.sigma_w2*self.inv_o*(k_x*o_x+k_y*o_y+k_z*o_z).detach().cpu().numpy()

        return eq1, eq2, eq3, eq4, eq5, eq6

    @torch.jit.script
    def autograd(y: torch.Tensor, x: List[torch.Tensor]) -> List[torch.Tensor]:
        """
        TorchScript function to compute the gradient of a tensor wrt multople inputs
        """
        grad_outputs: List[Optional[torch.Tensor]] = [torch.ones_like(y, device=y.device)]
        grad = torch.autograd.grad(
            [
                y,
            ],
            x,
            grad_outputs=grad_outputs,
            create_graph=True,
            allow_unused=True,
            #retain_graph=True,
        )

        if grad is None:
            grad = [torch.zeros_like(xx) for xx in x]
        assert grad is not None
        grad = [g if g is not None else torch.zeros_like(x[i]) for i, g in enumerate(grad)]
        return grad

    def predict(self, x_star, y_star, z_star, u_star, v_star, w_star, num_epoch=None):
        x_test = torch.tensor(x_star).float().to(device)
        y_test = torch.tensor(y_star).float().to(device)
        z_test = torch.tensor(z_star).float().to(device)
        u_test = torch.tensor(u_star).float().to(device)
        v_test = torch.tensor(v_star).float().to(device)
        w_test = torch.tensor(w_star).float().to(device)

        #self.dnn.eval()
        u_pred, v_pred, w_pred, p_pred,_,_ = self.neural_net_u(x_test, y_test, z_test)
        # Prediction
        u_pred = tonp(u_pred)
        v_pred = tonp(v_pred)
        w_pred = tonp(w_pred)
        p_pred = tonp(p_pred)
        # print(p_pred)
        # # Error
        # error_u = np.linalg.norm(u_test - u_pred, 2) / np.linalg.norm(u_test, 2)
        # error_v = np.linalg.norm(v_test - v_pred, 2) / np.linalg.norm(v_test, 2)
        # print('------------------------')
        # print('Error u: %e' % (error_u))
        # print('Error v: %e' % (error_v))
        # print('------------------------')

        u_pred = u_pred.reshape(257, 257)
        v_pred = v_pred.reshape(257, 257)
        w_pred = w_pred.reshape(257, 257)
        p_pred = p_pred.reshape(257, 257)

        result_folder = 'result_uvwdata'
        os.makedirs(result_folder, exist_ok=True)

        # 保存.mat文件到新建文件夹中
        mat_file_path = os.path.join(result_folder, 'f1_result_epoch%d.mat' % (num_epoch))
        scipy.io.savemat(mat_file_path,
                         {'U_pred': u_pred,
                          'V_pred': v_pred,
                          'W_pred': w_pred,
                          'P_pred': p_pred,
                          'lam_bcs':self.alpha_b,
                          'lam_equ':self.alpha_e})

    def shuffle(self, tensor):
        tensor_to_numpy = tensor.detach().cpu()
        shuffle_numpy = np.random.shuffle(tensor_to_numpy)
        return torch.tensor(tensor_to_numpy, requires_grad=True).float()

    def fwd_computing_loss_2d(self, loss_mode='MSE'):
        # boundary data
        (self.u_pred_b, self.v_pred_b, _, _) = self.neural_net_u(self.x_b, self.y_b)

        # BC loss
        if loss_mode == 'L2':
            self.loss_b = torch.norm((self.u_b.reshape([-1]) - self.u_pred_b.reshape([-1])), p=2) + \
                          torch.norm((self.v_b.reshape([-1]) - self.v_pred_b.reshape([-1])), p=2) + \
                          torch.norm((self.w_b.reshape([-1]) - self.w_pred_b.reshape([-1])), p=2)
        if loss_mode == 'MSE':
            self.loss_b = torch.mean(torch.square(self.u_b.reshape([-1]) - self.u_pred_b.reshape([-1]))) + \
                          torch.mean(torch.square(self.v_b.reshape([-1]) - self.v_pred_b.reshape([-1]))) + \
                          torch.mean(torch.square(self.w_b.reshape([-1]) - self.w_pred_b.reshape([-1])))

        # equation
        assert self.x_f is not None and self.y_f is not None

        (self.eq1_pred, self.eq2_pred,
         self.eq3_pred, self.eq4_pred,
         self.eq5_pred, self.eq6_pred) = self.neural_net_equations(self.x_f, self.y_f, self.z_f)
        if loss_mode == 'L2':
            self.loss_e = torch.norm(self.eq1_pred.reshape([-1]), p=2) + \
                          torch.norm(self.eq2_pred.reshape([-1]), p=2) + \
                          torch.norm(self.eq3_pred.reshape([-1]), p=2) + \
                          torch.norm(self.eq4_pred.reshape([-1]), p=2) + \
                          torch.norm(self.eq5_pred.reshape([-1]), p=2) + \
                          torch.norm(self.eq6_pred.reshape([-1]), p=2)
        if loss_mode == 'MSE':
            self.loss_eq1 = torch.mean(torch.square(self.eq1_pred.reshape([-1])))
            self.loss_eq2 = torch.mean(torch.square(self.eq2_pred.reshape([-1])))
            self.loss_eq3 = torch.mean(torch.square(self.eq3_pred.reshape([-1])))
            self.loss_eq4 = torch.mean(torch.square(self.eq4_pred.reshape([-1])))
            self.loss_eq5 = torch.mean(torch.square(self.eq5_pred.reshape([-1])))
            self.loss_eq6 = torch.mean(torch.square(self.eq6_pred.reshape([-1])))
            self.loss_e = self.loss_eq1+self.loss_eq2+self.loss_eq3 + 0.1*self.loss_eq4 + self.loss_eq5 + self.loss_eq6

        self.loss = self.alpha_b * self.loss_b + self.alpha_e * self.loss_e

        return self.loss, [self.loss_e, self.loss_b]

    def train(self,
              num_epoch=1,
              lr=1e-4,
              optimizer=None,
              scheduler=None,
              batchsize=None):
        if self.opt is not None:
            self.opt.param_groups[0]['lr'] = lr
        else:
            self.opt = torch.optim.Adam(list(self.net.parameters())+list(self.net_1.parameters()), lr=lr)
        return self.solve_Adam(self.fwd_computing_loss_2d, num_epoch, batchsize, scheduler)

    def solve_Adam(self,
                   loss_func,
                   num_epoch=1000,
                   batchsize=None,
                   scheduler=None):
        self.freeze_evm_net(0)
        for epoch_id in range(num_epoch):
            # train evm net every 10000 step
            if epoch_id !=0 and epoch_id % 5000 == 0:
                self.defreeze_evm_net(epoch_id)
            if (epoch_id - 1) % 5000 == 0:
                self.freeze_evm_net(epoch_id)

            loss, losses = loss_func()


            loss.backward()
            self.opt.step()
            self.opt.zero_grad()
            if scheduler:
                scheduler.step()

            if epoch_id == 0 or (epoch_id + 1)%100 == 0:
                l2_u, l2_v = self.test()
               # l2_u = l2u.detach().cpu().numpy()
               # l2_v = l2v.detach().cpu().numpy()
                self.print_log(loss, losses, l2_u, l2_v, epoch_id, num_epoch)


    def freeze_evm_net(self, epoch_id):
        for para in self.net_1.parameters():
            para.requires_grad = False
        self.opt.param_groups[0]['params'] = list(self.net.parameters())

    def defreeze_evm_net(self, epoch_id):
        for para in self.net_1.parameters():
            para.requires_grad = True
        self.opt.param_groups[0]['params'] = list(self.net.parameters())+list(self.net_1.parameters())


    def print_log(self, loss, losses, l2_u, l2_v, epoch_id, num_epoch):
        def get_lr(optimizer):
            for param_group in optimizer.param_groups:
                return param_group['lr']

        print("current lr is {}".format(get_lr(self.opt)))
        if isinstance(losses[0], int):
            eq_loss = losses[0]
        else:
            eq_loss = losses[0].detach().cpu().item()

        print("epoch/num_epoch: ", epoch_id + 1, "/", num_epoch,
              "loss[Adam]: %.3e"
              %(loss.detach().cpu().item()), 
              "eq_loss: %.3e " %(losses[0].detach().cpu().item()),
              "bc_loss: %.3e" %(losses[1].detach().cpu().item()),
              "l2_u: %.3e" %(l2_u.item()),
              "l2_v: %.3e" %(l2_v.item()))

    def test(self):
        """ testing all points in the domain """
        # Prediction
        u_pred, v_pred, _, _ = self.neural_net_u(self.x_star, self.y_star)
        u_pred = u_pred.detach().cpu().numpy().reshape(-1,1)
        v_pred = v_pred.detach().cpu().numpy().reshape(-1,1)
        u_star = self.u_star.detach().cpu().numpy().reshape(-1,1)
        v_star = self.v_star.detach().cpu().numpy().reshape(-1,1)
        # Error
        error_u = np.linalg.norm(u_star-u_pred,2)/np.linalg.norm(u_star,2)
        error_v = np.linalg.norm(v_star-v_pred,2)/np.linalg.norm(v_star,2)

        self.L2_u.append(error_u)
        self.L2_v.append(error_v)

        return error_u, error_v
