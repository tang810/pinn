# Copyright (c) 2023 scien42.tech, Se42 Authors. All Rights Reserved.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Author: Zhicheng Wang, Hui Xiang
# Created: 08.03.2023
import torch
from tools import *
#import cavity_data as cavity
#import pinn_solver as psolver
import rans_data as rdata
import pinn_solver_2D as psolver


def test(net_params=None, net_params_1=None, loop = 0):
    nu_0 = 1e-5   # kinetic viscosity
    U_0 = 1.0 
    rho_0 = 1.0 
    L_0 = 1.0
    N_neu = 120
    N_neu_1 = 40
    lam_bcs = 10
    lam_equ = 1
    N_f = 40000
    alpha_evm = 0.03
    beta_evm = 10.0
    N_HLayer = 4
    N_HLayer_1 = 4
   
    PINN = psolver.PysicsInformedNeuralNetwork(
        nu_0 = nu_0,
        U_0 = U_0,
        rho_0 = rho_0,
        L_0 = L_0,
        layers=N_HLayer,
        layers_1=N_HLayer_1,
        hidden_size = N_neu,
        hidden_size_1 = N_neu_1,
        N_f = N_f,
        alpha_evm=alpha_evm,
        beta_evm=beta_evm,
        bc_weight=lam_bcs,
        eq_weight=lam_equ,
        net_params=net_params,
        checkpoint_path='./checkpoint/')
    
    path = './datasets/'
    dataloader = rdata.DataLoader(path=path, N_f=N_f, N_b=1000)
    filename = './data/Re1e5_backStep_L8.mat'
    x_star, y_star, u_star, v_star, p_star, k_star, o_star, n_star = dataloader.loading_evaluate_data(filename)
    PINN.set_testing_data(x_star,y_star,u_star,v_star, p_star, k_star, o_star)
    #PINN.evaluate(x_star, y_star, u_star, v_star)
    PINN.test()
    PINN.predict(x_star, y_star, u_star, v_star)

if __name__ == "__main__":
    net_params = 'results/Re100000/4x120_Nf40k_lamB10_alpha0.03/model_loop90000.pth'
    net_params_1 = 'results/Re100000/4x120_Nf40k_lamB10_alpha0.03/model_loop90000.pth_evm'
    test(net_params=net_params, net_params_1=net_params_1)
    #net_params = '/mnt/sdb/ai4s_checkpoints/model_200000_003.pth'
    #test(net_params=net_params)
