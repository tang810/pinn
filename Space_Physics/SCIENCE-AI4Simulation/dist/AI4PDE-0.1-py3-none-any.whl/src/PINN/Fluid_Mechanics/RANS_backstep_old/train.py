import torch
from tools import *
import rans_data as rdata
import pinn_solver_2D as psolver


def train(net_params=None):
    for loop in range(0,1):
        nu_0 = 1e-5   # kinetic viscosity
        U_0 = 1.0 
        rho_0 = 1.0 
        L_0 = 1.0
        N_neu = 120
        N_neu_1 = 40
        lam_bcs = 10
        lam_equ = 1
        N_f = 40000
        alpha_evm = 0.03
        beta_evm = 10.0
        N_HLayer = 4
        N_HLayer_1 = 4
    
        PINN = psolver.PysicsInformedNeuralNetwork(
            nu_0 = nu_0,
            U_0 = U_0,
            rho_0 = rho_0,
            L_0 = L_0,
            layers=N_HLayer,
            layers_1=N_HLayer_1,
            hidden_size = N_neu,
            hidden_size_1 = N_neu_1,
            N_f = N_f,
            alpha_evm=alpha_evm,
            beta_evm=beta_evm,
            bc_weight=lam_bcs,
            eq_weight=lam_equ,
            net_params=net_params,
            checkpoint_path='./checkpoint/')
    
        path = './datasets/'
        dataloader = rdata.DataLoader(path=path, N_f=N_f, N_b=1000)
    
        bc_UV = './data/Re1e5_backStep_BC_UV_L8.mat'
        bc_P = './data/Re1e5_backStep_BC_P_L8.mat'
        #bc_KO = './data/Re1e5_BC_KO.mat'
        # Set boundary data, | u, v, x, y
        uvk_wall_data, uvk_io_data,p_b_data = dataloader.loading_boundary_data(bc_UV,bc_P,nu_0)
#        PINN.set_sym_boundary_data(X=vb_up_data)
        PINN.set_io_boundary_data(X=uvk_io_data)
        PINN.set_pres_boundary_data(X=p_b_data)
        PINN.set_wall_boundary_data(X=uvk_wall_data)
#        PINN.set_ko_boundary_data(X=ko_b_data)
    
        # Set training data, | x, y
        training_data = dataloader.loading_training_data()
        PINN.set_eq_training_data(X=training_data)
    
        filename = './data/Re1e5_backStep_L8.mat'
        x_star, y_star, u_star, v_star, p_star, k_star, o_star, n_star = dataloader.loading_evaluate_data(filename)
    
        PINN.set_testing_data(x_star,y_star,u_star,v_star, p_star, k_star, o_star)

        # Training
        epoch=100000
        PINN.set_alpha_evm(0.05)
        PINN.train(num_epoch=epoch, lr=1e-3)
        PINN.predict(x_star, y_star, u_star, v_star, 100000)
        
        PINN.set_alpha_evm(0.03)
        PINN.train(num_epoch=epoch, lr=2e-4)
        PINN.predict(x_star, y_star, u_star, v_star, 200000)

        '''
        PINN.set_alpha_evm(0.02)
        PINN.train(num_epoch=epoch, lr=5e-5)
        PINN.predict(x_star, y_star, u_star, v_star, 300000)

        PINN.set_alpha_evm(0.01)
        PINN.train(num_epoch=epoch, lr=5e-5)
        PINN.predict(x_star, y_star, u_star, v_star, 400000)
                  
        PINN.set_alpha_evm(0.005)
        PINN.train(num_epoch=300000, lr=1e-5)
        PINN.predict(x_star, y_star, u_star, v_star, 1500000,loop)
    
        PINN.set_alpha_evm(0.002)
        PINN.train(num_epoch=500000, lr=2e-6)
        PINN.predict(x_star, y_star, u_star, v_star, 2000000,loop)
        '''
if __name__ == "__main__":
     train()
