import deepxde as dde
import numpy as np
from data import a, c0, c1, c2, lamda


def pde(x, y):
    dy_t = dde.grad.jacobian(y, x, i=0, j=1)
    dy_x = dde.grad.jacobian(y, x, i=0, j=0)
    dy_xx = dde.grad.hessian(y, x, i=0, j=0)
    dy_xxx = dde.grad.jacobian(dy_xx, x, i=0, j=0)
    return dy_t + c0 * dy_x + c1 * y * dy_x + c2 * dy_xxx


def create_pinn():
    geom = dde.geometry.Interval(-10, 40)
    timedomain = dde.geometry.TimeDomain(0, 4)
    geomtime = dde.geometry.GeometryXTime(geom, timedomain)

    bc = dde.icbc.PeriodicBC(geomtime, 0, lambda _, on_boundary: on_boundary)
    ic = dde.icbc.IC(geomtime, lambda x: a * (1.0 / np.cosh(x[:, 0:1] / lamda))**2, lambda _, on_initial: on_initial)

    data = dde.data.TimePDE(
        geomtime,
        pde,
        [bc, ic],
        num_domain=2540,
        num_boundary=80,
        num_initial=160,
        num_test=2540,
    )
    return data
