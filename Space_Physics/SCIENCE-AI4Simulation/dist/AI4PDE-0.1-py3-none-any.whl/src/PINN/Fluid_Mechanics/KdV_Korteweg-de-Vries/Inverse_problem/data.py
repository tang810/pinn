import numpy as np

a = -0.77
c_t = 0.5549706945768627
lamda_t = 3.1031120097882274


def kdv_eq_exact_solution(x, t):
    """Korteweg–de Vries equation exact solution."""
    return a * (1.0 / np.cosh((x - c_t * t) / lamda_t))**2


def gen_exact_solution():
    """Generates exact solution and saves it to a file."""
    x_dim, t_dim = (256, 201)
    x_min, t_min = (-10, 0.0)
    x_max, t_max = (40, 4.0)

    t = np.linspace(t_min, t_max, num=t_dim).reshape(t_dim, 1)
    x = np.linspace(x_min, x_max, num=x_dim).reshape(x_dim, 1)
    usol = np.zeros((x_dim, t_dim))

    for i in range(x_dim):
        for j in range(t_dim):
            usol[i][j] = kdv_eq_exact_solution(x[i], t[j])

    np.savez("heat_eq_data", x=x, t=t, usol=usol)


def gen_testdata():
    """Loads and preprocesses the exact solution data."""
    data = np.load("heat_eq_data.npz")
    t, x, exact = data["t"], data["x"], data["usol"].T
    xx, tt = np.meshgrid(x, t)
    X = np.vstack((np.ravel(xx), np.ravel(tt))).T
    y = exact.flatten()[:, None]
    return X, y


# Generate data when the script is executed directly.
if __name__ == "__main__":
    gen_exact_solution()
