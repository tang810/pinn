import deepxde as dde
from data import gen_testdata
from net import create_network
from pinn import create_pinn, c0, c1, c2

# Load test data
observe_x, y = gen_testdata()

# Define PINN
data = create_pinn(observe_x, y)
net = create_network()
model = dde.Model(data, net)

# Train the model
model.compile("adam", lr=1e-3, external_trainable_variables=[c0, c1, c2])
variable = dde.callbacks.VariableValue(
    [c0, c1, c2], period=1, filename="./test.txt", precision=6
)
losshistory, train_state = model.train(iterations=25000, callbacks=[variable])

# Save results
dde.saveplot(losshistory, train_state, issave=True, isplot=True)
