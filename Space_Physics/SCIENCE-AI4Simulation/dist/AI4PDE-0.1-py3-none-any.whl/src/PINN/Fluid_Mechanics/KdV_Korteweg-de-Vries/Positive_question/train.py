import deepxde as dde
from data import gen_exact_solution, gen_testdata
from net import create_network
from pinn import create_pinn

# Generate exact solution data
gen_exact_solution()

# Define PDE problem and network
data = create_pinn()
net = create_network()
model = dde.Model(data, net)

# Train the model
model.compile("adam", lr=1e-3)
losshistory, train_state = model.train(iterations=20000)
dde.saveplot(losshistory, train_state, issave=True, isplot=True)

# Test the model
X, y_true = gen_testdata()
y_pred = model.predict(X)
f = model.predict(X, operator=data.pde)
print("Mean residual:", np.mean(np.absolute(f)))

# Save test results
np.savetxt("test.dat", np.hstack((X, y_true, y_pred)))
