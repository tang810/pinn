import numpy as np

a = -0.77
rho1 = 1
rho2 = 0.977
h1 = 4.13
h2 = 1
g = 9.81

c0 = np.sqrt(g * h1 * h2 * (rho1 - rho2) / (rho1 * h2 + rho2 * h1))
c1 = -(3 / 2) * c0 * ((rho2 * h1**2 - rho1 * h2**2) / (rho2 * h2 * h1**2 + rho1 * h1 * h2**2))
c2 = (1 / 6) * c0 * ((rho2 * h2**2 * h1 + rho1 * h1**2 * h2) / (rho2 * h1 + rho1 * h2))
c = c0 + a * c1 / 3
lamda = np.sqrt(12 * c2 / (a * c1))


def kdv_eq_exact_solution(x, t):
    return a * (1.0 / np.cosh((x - c * t) / lamda))**2


def gen_exact_solution():
    x_dim, t_dim = (256, 201)
    x_min, t_min = (-10, 0.0)
    x_max, t_max = (40, 4.0)
    t = np.linspace(t_min, t_max, num=t_dim).reshape(t_dim, 1)
    x = np.linspace(x_min, x_max, num=x_dim).reshape(x_dim, 1)
    usol = np.zeros((x_dim, t_dim))

    for i in range(x_dim):
        for j in range(t_dim):
            usol[i, j] = kdv_eq_exact_solution(x[i], t[j])

    np.savez("heat_eq_data", x=x, t=t, usol=usol)


def gen_testdata():
    data = np.load("heat_eq_data.npz")
    t, x, exact = data["t"], data["x"], data["usol"].T
    xx, tt = np.meshgrid(x, t)
    X = np.vstack((np.ravel(xx), np.ravel(tt))).T
    y = exact.flatten()[:, None]
    return X, y
