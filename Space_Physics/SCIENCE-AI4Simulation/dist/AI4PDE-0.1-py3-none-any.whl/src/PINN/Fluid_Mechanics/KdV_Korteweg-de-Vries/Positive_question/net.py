import deepxde as dde


def create_network():
    return dde.nn.FNN([2] + [20] * 3 + [1], "tanh", "Glorot normal")
