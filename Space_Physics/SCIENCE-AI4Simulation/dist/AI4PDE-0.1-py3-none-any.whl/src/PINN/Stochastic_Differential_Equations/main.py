import numpy as np
import torch
import torch.optim as optim
import torch.nn as nn
import scipy.linalg as la
import time

from model import *


# define loss function
def criterion(u, k, f, u_recon, k_recon, f_recon, z, device):
    MMD = MMD_loss()
    recon = torch.cat((u_recon, k_recon, f_recon), dim = 1)
    ref = torch.cat((u, k, f), dim = 1)
    loss_recon = MMD(recon,ref) 
    zc = torch.randn_like(z).to(device)
    KLD = MMD(z, zc)
    
    return KLD + loss_recon 


# training function
def train(epoch,train_loader,model,optimize_operator,criterion,device):
    train_loss = 0
    for batch_idx, (u, k, f, u_coor, k_coor, f_coor) in enumerate(train_loader):
        u, k, f = u.to(device), k.to(device), f.to(device)
        u_coor, k_coor, f_coor = u_coor.to(device), k_coor.to(device), f_coor.to(device)

        optimize_operator.zero_grad()
        u_recon, k_recon, f_recon, Z = model.forward(u, k, f, u_coor, k_coor, f_coor)
        loss = criterion(u, k, f, u_recon, k_recon, f_recon, Z, device)
        loss.backward()
        train_loss += loss.item()
        optimize_operator.step()
    
    return model, loss

def lbfgs(train_loader):
    def closure():

        for batch_idx, (u, k, f, u_coor, k_coor, f_coor) in enumerate(train_loader):
            u, k, f = u.to(device), k.to(device), f.to(device)
            u_coor, k_coor, f_coor = u_coor.to(device), k_coor.to(device), f_coor.to(device)

            optimize_operator.zero_grad()
            u_recon, k_recon, f_recon, Z = model.forward(u, k, f, u_coor, k_coor, f_coor)
            loss = criterion(u, k, f, u_recon, k_recon, f_recon, Z, device)
            loss.backward()
        return loss
    return closure



# function of calculate std on the validation points
def std_cal(A):
    mean = torch.mean(A,axis=0)
    A = (A - mean)
    std = 0
    for i in range(A.size(0)):
        std += torch.norm(A[i,:])**2
    std = torch.sqrt(std / A.size(0))
    return std


if __name__ == "__main__":

    ## Hyper-par
    data_size = 2000
    u_sensor = 2
    k_sensor = 17
    f_sensor = 21
    batch = 1000
    epoch = 10000
    mesh_size = 400
    latent_dim = 4

    layer_encoder = [u_sensor + k_sensor + f_sensor] + [128]*3 + [latent_dim]
    layer_decoder = [latent_dim+1] + [128]*3 + [1]

    '''------------------------------------ Data -------------------------------'''

    device = torch.device('cuda:3') if torch.cuda.is_available() else torch.device('cpu')

    u_data = np.load(file='data/u.npy')[0: data_size]
    k_data = np.load(file='data/k.npy')[0: data_size]
    f_data = np.load(file='data/f.npy')[0: data_size]

    '''------------------------------------ Test -------------------------------'''
    # calculate ground true for comparison
    n_validate = 201    # number of validation points
    test_coor = np.floor(np.linspace(0, 1, n_validate) * mesh_size).astype(int)
    u_test, k_test, f_test = u_data[:, test_coor], k_data[:, test_coor], f_data[:, test_coor]


    true_mean_u = torch.mean(torch.from_numpy(u_test), axis=0).type(torch.float).to(device)
    true_std_u = std_cal(torch.from_numpy(u_test)).type(torch.float).to(device)

    true_mean_k = torch.mean(torch.from_numpy(k_test), axis=0).type(torch.float).to(device)
    true_std_k = std_cal(torch.from_numpy(k_test)).type(torch.float).to(device)

    # calculate u reference solution
    std, mean = np.std(u_data, axis=0), np.mean(u_data, axis=0)

    low, up = mean - std, mean + std
    u_ref = np.vstack((low, mean, up))

    # calculate k reference solution
    std, mean = np.std(k_data, axis=0), np.mean(k_data, axis=0)

    low, up = mean - std, mean + std
    k_ref = np.vstack((low, mean, up))

    '''------------------------------------ Model -------------------------------'''
    # define models
    model = PI_VAE(layer_encoder, layer_decoder, device)
    optimize_operator = optim.Adam(model.parameters(), lr=1e-3, betas=(0.5, 0.9))

    '''--------------------------------- Train data -------------------------------'''
    # define training data loader
    u_coor = np.linspace(-1, 1, u_sensor) * np.ones([len(u_data), u_sensor])
    k_coor = np.linspace(-1, 1, k_sensor) * np.ones([len(k_data), k_sensor])
    f_coor = np.linspace(-1, 1, f_sensor) * np.ones([len(f_data), f_sensor])


    x_u_coor = np.floor(np.linspace(0, 1, u_sensor) * mesh_size).astype(int)
    x_k_coor = np.floor(np.linspace(0, 1, k_sensor) * mesh_size).astype(int)
    x_f_coor = np.floor(np.linspace(0, 1, f_sensor) * mesh_size).astype(int)

    k_training_data = k_data[0: data_size, x_k_coor]
    u_training_data = u_data[0: data_size, x_u_coor]
    f_training_data = f_data[0: data_size, x_f_coor]   

    VAE_train_loader = trainingset_construct_SDE(u_data=u_training_data, k_data=k_training_data, f_data=f_training_data, 
                                         x_u=u_coor, x_k=k_coor, x_f=f_coor, batch_val=batch)



    '''--------------------------------- Train step -------------------------------'''
    u_mean_error = []
    u_std_error = []
    k_mean_error = []
    k_std_error = []
    time_history = []
    loss_history = []

    for epoch in range(epoch):

        time_start = time.time()
        model, L = train(epoch, VAE_train_loader, model, optimize_operator, criterion, device)
        time_stop = time.time()
        loss_history.append(L.detach().cpu().numpy())
        time_history.append(time_stop-time_start)



        if epoch % 100 == 0:

            '''--------------------------------- Test -------------------------------'''

            with torch.no_grad():

                # 随机生成隐变量
                z = torch.randn(1000, latent_dim).to(device)

                # 测试坐标
                coordinate = (torch.linspace(-1,1,steps=n_validate) * torch.ones((1000,n_validate))).to(device)
                
                # decode
                u_recon = model.decoder_u(model.combine_xz(coordinate, z)).view(-1,n_validate)
                k_recon = model.decoder_k(model.combine_xz(coordinate, z)).view(-1,n_validate)
                
                mean_u, std_u = torch.mean(u_recon,axis=0), std_cal(u_recon)
                mean_k, std_k = torch.mean(k_recon,axis=0), std_cal(k_recon)
                

                mean_L2_error_u = (torch.norm(mean_u-true_mean_u)/torch.norm(true_mean_u)).cpu().numpy()
                std_L2_error_u = (torch.norm(std_u-true_std_u)/torch.norm(true_std_u)).cpu().numpy()
                u_mean_error.append(mean_L2_error_u)
                u_std_error.append(std_L2_error_u)
                
                
                mean_L2_error_k = (torch.norm(mean_k-true_mean_k)/torch.norm(true_mean_k)).cpu().numpy()
                std_L2_error_k = (torch.norm(std_k-true_std_k)/torch.norm(true_std_k)).cpu().numpy()
                k_mean_error.append(mean_L2_error_k)
                k_std_error.append(std_L2_error_k)
                print('epoch:%d, u mean:%.3e, u std:%.3e, k mean:%.3e, k std:%.3e'%(epoch, mean_L2_error_u, std_L2_error_u, mean_L2_error_k, std_L2_error_k))

    optimizer_lbfgs = torch.optim.LBFGS(model.parameters(), 1, max_iter = 10000, max_eval = None, 
                        tolerance_grad = 1e-11, tolerance_change = 1e-11, history_size = 100, line_search_fn = 'strong_wolfe')
    closure = lbfgs(VAE_train_loader)
    optimizer_lbfgs.step(closure)

    torch.save(model, 'model/model.pkl')

    # print(model)