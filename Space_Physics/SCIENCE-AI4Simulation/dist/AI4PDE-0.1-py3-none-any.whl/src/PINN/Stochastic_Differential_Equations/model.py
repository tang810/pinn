import torch
import torch.optim as optim
import torch.nn as nn
# from torch.autograd import Variable

from collections import OrderedDict

'''定义一个全连接神经网络'''
class DNN(nn.Module):
    def __init__(self, layer, device, activation=torch.nn.Tanh):
        super(DNN, self).__init__()

        self.activation = activation
        self.initialize_NN(layer, device)

    def forward(self, x):
        return self.Model(x)
    
    def initialize_NN(self, layers, device):
        model = []
        for i in range(len(layers) - 2):
            
            model.append((f"Linear_{i}", torch.nn.Linear(layers[i], layers[i+1], bias=True)))
            model.append((f"activation_{i}", self.activation()))
        model.append((f"Linear_{len(layers)-2}", torch.nn.Linear(layers[-2], layers[-1], bias=True)))

        self.Model = torch.nn.Sequential(OrderedDict(model)).to(device)

'''定义PI-VAE'''
class PI_VAE(nn.Module):
    def __init__(self, layer_encode, layer_decode, device):
        super(PI_VAE, self).__init__()
        
        self.device = device
        self.encoder = DNN(layer_encode[:-1], device)
        self.encoder_mu = DNN(layer_encode[-2:], device)
        self.encoder_var = DNN(layer_encode[-2:], device, activation=nn.Sigmoid)

        self.decoder_u = DNN(layer_decode, device)
        self.decoder_k = DNN(layer_decode, device)

    # 将潜变量与坐标拼在一起
    def combine_xz(self, x, z):    # x是一个n行矩阵，z是一个列向量
        x_new = x.view(-1,1)
        z_new = torch.repeat_interleave(z, x.size(-1), dim=0) # .view(-1,self.latent_dim)
        return torch.cat((x_new,z_new),1)
    
    # 编码层
    def encode(self, u, k, f):
        out = self.encoder(torch.cat((u,k,f),dim=1))
        mu = self.encoder_mu(out)
        std = torch.sqrt(torch.exp(self.encoder_var(out)))
        return mu + std * torch.randn_like(std).to(self.device)
    
    # 解码层
    def funval_cal(self, z, u_coor, k_coor):
        u_recon = self.decoder_u(self.combine_xz(u_coor, z)).view(-1,u_coor.size(1))
        k_recon = self.decoder_k(self.combine_xz(k_coor, z)).view(-1,k_coor.size(1))

        return u_recon, k_recon
    
    def PDE_check(self, z, f_coor, device):
        x = torch.tensor(f_coor.view(-1,1).type(torch.FloatTensor), requires_grad=True).to(device)
        z_uk = torch.repeat_interleave(z, f_coor.size(1), dim=0)
        
        val_u = torch.cat((x,z_uk),1)
        val_k = torch.cat((x,z_uk),1)

        u_PDE = self.decoder_u(val_u)
        u_PDE_x = torch.autograd.grad(outputs=u_PDE, inputs=x, grad_outputs=torch.ones(u_PDE.size()).to(device),create_graph=True, only_inputs=True)[0]
        u_PDE_xx = torch.autograd.grad(outputs=u_PDE_x, inputs=x, grad_outputs=torch.ones(u_PDE_x.size()).to(device),create_graph=True, only_inputs=True)[0]
        
        k_PDE = self.decoder_k(val_k)
        k_PDE_x = torch.autograd.grad(outputs=k_PDE, inputs=x, grad_outputs=torch.ones(k_PDE.size()).to(device),create_graph=True, only_inputs=True)[0]
        f_recon = -0.1*(k_PDE_x * u_PDE_x + k_PDE * u_PDE_xx).view(-1,f_coor.size(1))

        return f_recon
    
    def forward(self, u, k, f, u_coor, k_coor, f_coor):
        Z = self.encode(u, k, f)
        u_recon, k_recon = self.funval_cal(Z, u_coor, k_coor)
        f_recon = self.PDE_check(Z, f_coor, self.device)
        
        return u_recon, k_recon, f_recon, Z
    

'''计算MMD损失'''
class MMD_loss(nn.Module):
    'description'
    # function class which calculates the MMD distance of 2 distributions

    def __init__(self, kernel_mul = 2.0, kernel_num = 5):
        super(MMD_loss, self).__init__()

        self.kernel_num = kernel_num
        self.kernel_mul = kernel_mul
        self.fix_sigma = None
        return
    
    def guassian_kernel(self, source, target, kernel_mul=2.0, kernel_num=5, fix_sigma=None):
        n_samples = int(source.size()[0])+int(target.size()[0])
        total = torch.cat([source, target], dim=0)

        ## 计算L-2距离矩阵
        total0 = total.unsqueeze(0).expand(int(total.size(0)), int(total.size(0)), int(total.size(1)))
        total1 = total.unsqueeze(1).expand(int(total.size(0)), int(total.size(0)), int(total.size(1)))
        L2_distance = ((total0-total1)**2).sum(2) 

        ## 计算带宽
        if fix_sigma:
            bandwidth = fix_sigma
        else:
            bandwidth = torch.sum(L2_distance.data) / (n_samples**2-n_samples)
        bandwidth /= kernel_mul ** (kernel_num // 2)
        bandwidth_list = [bandwidth * (kernel_mul**i) for i in range(kernel_num)]
        kernel_val = [torch.exp(-L2_distance / bandwidth_temp) for bandwidth_temp in bandwidth_list]
        return sum(kernel_val)

    def forward(self, source, target):
        batch_size = int(source.size()[0])
        kernels = self.guassian_kernel(source, target, kernel_mul=self.kernel_mul, kernel_num=self.kernel_num, fix_sigma=self.fix_sigma)
        XX = kernels[:batch_size, :batch_size]
        YY = kernels[batch_size:, batch_size:]
        XY = kernels[:batch_size, batch_size:]
        YX = kernels[batch_size:, :batch_size]
        loss = torch.mean(XX + YY - XY -YX)
        return loss
    

'''data_loader, 用于批量训练'''
from torch.utils.data import Dataset, DataLoader

# define training loader construction function
class MyDataset_SDE(Dataset):
    def __init__(self, u_data, k_data, f_data, x_u, x_k, x_f, transform=None):
        self.u_data = torch.from_numpy(u_data).float()
        self.k_data = torch.from_numpy(k_data).float()
        self.f_data = torch.from_numpy(f_data).float()
        self.x_u = torch.from_numpy(x_u).float()
        self.x_k = torch.from_numpy(x_k).float()
        self.x_f = torch.from_numpy(x_f).float()
        self.transform = transform
        
    def __getitem__(self, index):
        u = self.u_data[index]
        k = self.k_data[index]
        f = self.f_data[index]
        u_coor = self.x_u[index]
        k_coor = self.x_k[index]
        f_coor = self.x_f[index]
        
        if self.transform:
            u = self.transform(u)
            k = self.transform(k)
            f = self.transform(f)
        
        return u, k, f, u_coor, k_coor, f_coor
    
    def __len__(self):
        return len(self.u_data)     # batch index 's total number 


def trainingset_construct_SDE(u_data, k_data, f_data, x_u, x_k, x_f, batch_val):
    VAE_dataset = MyDataset_SDE(u_data, k_data, f_data, x_u, x_k, x_f)

    return DataLoader(
        VAE_dataset,
        batch_size=batch_val,
        shuffle=True,                     # change the sequence of the data every time
        num_workers=0,
        pin_memory=torch.cuda.is_available()
    )