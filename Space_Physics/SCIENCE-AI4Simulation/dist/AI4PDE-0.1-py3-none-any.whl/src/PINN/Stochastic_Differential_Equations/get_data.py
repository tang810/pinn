import scipy.sparse as ss
import scipy.sparse.linalg as sla
import numpy as np
import scipy.sparse as ss
from scipy.sparse.linalg import spsolve
import seaborn as sns
import matplotlib.pyplot as plt



'''获得SDE的相关数据的类'''
class SDE():

    '''mesh_size: 将[-1, 1]区间分成多少个点'''
    def __init__(self, mesh_size):
        super(SDE, self).__init__()
        self.mesh_size = mesh_size

    '''获取数据'''
    def __call__(self, Num, kL, fL):
        k_samples, f_samples, u_samples = [], [], []

        '''定义一个多元正态分布'''
        rng = np.random.RandomState(15)           # define a random state
        x = np.linspace(-1, 1, self.mesh_size+1)  # construct the coordinate of x：401 points uniformly distributed on [-1,1]
        
        # construct corresponding mean function and covariance matrix of the stoachastic process
        '''高斯核的均值和协方差'''
        mean_k, cov_k  = self.khat_m(x), self.khat_k(x,x,l=kL)
        mean_f, cov_f = self.f_m(x), self.f_k(x,x, l=fL)

        '''取得的一个满足多维正态分布的向量， 维度为num x dim'''
        Yk = rng.multivariate_normal(mean_k, cov_k, Num)
        Yf = rng.multivariate_normal(mean_f, cov_f, Num)
        
        # construct the sample paths of f(x) and k(x) (limited number: 300 or 1000 or 3000)
        for i in range(Num):

            k = self.k_Y(x,Yk[i])
            f = Yf[i]                       # sensor data
            u = self.u_solve(k, f)
            
            k_samples.append(k)
            f_samples.append(f)
            u_samples.append(u)
        return np.array(k_samples), np.array(f_samples), np.array(u_samples)

    '''k_hat的高斯核协方差'''
    def khat_k(self, xs, ys, l=1):      # khat(x) kernel function
        dx = np.expand_dims(xs, 1) - np.expand_dims(ys, 0)
        return (4/25) * np.exp(-((dx/l) ** 2))
    
    '''k_hat的高斯核均值'''
    def khat_m(self, x):          # khat(x) mean function
        return np.zeros_like(x)
    
    '''k计算公式'''
    def k_Y(self, k_X, khat_Y):    # calculate the function value of coefficient term
        k_Y = np.exp(0.2 * np.sin(1.5 * np.pi * (k_X+1)) + khat_Y)
        return k_Y
    
    '''f的高斯核函数协方差'''
    def f_k(self, xs, ys, sigma=1, l=1):    # f(x) kernel function
        dx = np.expand_dims(xs, 1) - np.expand_dims(ys, 0)
        return (sigma ** 2) * (9/400) * np.exp(- ((dx / l) ** 2))

    '''f的高斯核函数均值'''
    def f_m(self, x):             # f(x) mean function
        return np.zeros_like(x) + 0.5

    '''求解u'''
    def u_solve(self, k, f):
        h = 2/self.mesh_size            # step
        
        '''有限差分近似u'''
        # construct matrix A using second order approximation
        diag_up = (np.roll(k,-1) + 4*k - np.roll(k,1))[1:-2]
        diag_down = (np.roll(k,1) + 4*k - np.roll(k,-1))[2:-1]
        diag = -8 * k[1:-1]
        A = ss.csr_matrix(np.diag(diag) + np.diag(diag_up,1) + np.diag(diag_down,-1))
        
        b = - 40 * (h**2) * f[1: -1]
        
        # solve the system
        u = sla.spsolve(A,b)
        zero = np.array([0])
        u = np.concatenate((zero,u,zero),axis=0)
        return u



if __name__ == "__main__":

    '''
    参数解释：
    mesh_size,      int         将区域划分为mesh_size个, 用于对应计算u, k, f的数值
    data_size,      int         获得多少个数据, 即进行多少次多元高斯采样
    kl, fl          float       高斯核里对应k, f的超参数, 主要指带宽
                                论文里提供的参数设定为：低维-kl=1.0,fl=0.2, 高维-kl=0.02,fl=1.0, kl=1.0,fl=0.02
                                
    可以根据自身需要，将一下参数放到 argparse 里进行使用
    '''
    data_size = 5000
    mesh_size = 400
    kl = 1.0
    fl = 0.02

    k, f, u = SDE(mesh_size=mesh_size)(data_size, kl, fl)

    np.save(file='data/u.npy', arr=u)
    np.save(file='data/k.npy', arr=k)
    np.save(file='data/f.npy', arr=f)



