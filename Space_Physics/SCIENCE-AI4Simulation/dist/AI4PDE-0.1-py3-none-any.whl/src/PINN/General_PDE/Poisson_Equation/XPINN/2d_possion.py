'''
这里由于二维边界不规则， 因此比较复杂，没有画图， 直接使用论文里给的数据
'''


import torch
import numpy as np
from pyDOE import lhs
import matplotlib.pyplot as plt
import scipy


## 模型
class XPINNs:
    def __init__(self, X_u, u, X_f1, X_f2, X_f3, X_fi1, X_fi2, layers):
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

        # boundary
        self.x = torch.tensor(X_u[:, 0:1], requires_grad=True).float().to(self.device)
        self.t = torch.tensor(X_u[:, 1:2], requires_grad=True).float().to(self.device)
        self.u = torch.tensor(u, requires_grad=True).float().to(self.device)

        # train 这里有多个网络，因此有多个数据
        self.x1 = torch.tensor(X_f1[:, 0:1], requires_grad=True).float().to(self.device)
        self.t1 = torch.tensor(X_f1[:, 1:2], requires_grad=True).float().to(self.device)
        self.x2 = torch.tensor(X_f2[:, 0:1], requires_grad=True).float().to(self.device)
        self.t2 = torch.tensor(X_f2[:, 1:2], requires_grad=True).float().to(self.device)
        self.x3 = torch.tensor(X_f3[:, 0:1], requires_grad=True).float().to(self.device)
        self.t3 = torch.tensor(X_f3[:, 1:2], requires_grad=True).float().to(self.device)

        # interface     多个网络之间的边界
        self.xi1 = torch.tensor(X_fi1[:, 0:1], requires_grad=True).float().to(self.device)
        self.ti1 = torch.tensor(X_fi1[:, 1:2], requires_grad=True).float().to(self.device)
        self.xi2 = torch.tensor(X_fi2[:, 0:1], requires_grad=True).float().to(self.device)
        self.ti2 = torch.tensor(X_fi2[:, 1:2], requires_grad=True).float().to(self.device)

        self.loss_list, self.error_list = [], []
        # self.ub, self.lb = torch.tensor(ub).float().to(self.device), torch.tensor(lb).float().to(self.device)
        self.activation = torch.tanh

        ## 初始化各个网络
        self.weights1 ,self.biases1 = self.initialize_NN(layers[0])
        self.weights2 ,self.biases2 = self.initialize_NN(layers[1])
        self.weights3 ,self.biases3 = self.initialize_NN(layers[2])


    # 获得网络参数
    def initialize_NN(self, layer):
        weights, biases = [], []

        for i in range(len(layer) - 1):
            w = self.xavier_init(size=[layer[i], layer[i+1]])
            b = torch.zeros((1, layer[i+1]), requires_grad=True)

            weights.append(w)
            biases.append(b)
        return weights, biases
    
    # 对矩阵进行初始化 (μ=0 的正态分布)
    def xavier_init(self, size):
        in_dim, out_dim = size
        xavier_stddev = (2/(in_dim + out_dim))**(1/2)
        x = torch.normal(mean=0, std=xavier_stddev*torch.ones(in_dim, out_dim))
        x.requires_grad = True
        return x
    
    # 前向传播过程
    def neural_net(self, X, weights, biases):
            # H = 2*(X - self.lb)/(self.ub - self.lb) - 1
            H = X
            for i in range(len(weights) - 1):
                w, b = weights[i].float().to(self.device), biases[i].float().to(self.device)
                H = self.activation(torch.mm(H, w) + b)
            w, b = weights[-1].float().to(self.device), biases[-1].float().to(self.device)
            return torch.mm(H, w) + b 
    
    # 前向传播
    def net_u(self, x, t, weights, biases):
        return self.neural_net(torch.cat([x,t], 1), weights, biases)
    
    # Loss PDE
    def net_f(self, x1, t1, x2, t2, x3, t3, xi1, ti1, xi2, ti2):

        # Sub-net 1
        u1 = self.net_u(x1, t1, self.weights1, self.biases1)
        u1_t = torch.autograd.grad(u1, t1, grad_outputs=torch.ones_like(u1), retain_graph=True, create_graph=True)[0]
        u1_x = torch.autograd.grad(u1, x1, grad_outputs=torch.ones_like(u1), retain_graph=True, create_graph=True)[0]
        u1_tt = torch.autograd.grad(u1_t, t1, grad_outputs=torch.ones_like(u1_t), retain_graph=True, create_graph=True)[0]
        u1_xx = torch.autograd.grad(u1_x, x1, grad_outputs=torch.ones_like(u1_x), retain_graph=True, create_graph=True)[0]

        # Sub-net 2
        u2 = self.net_u(x2, t2, self.weights2, self.biases2)
        u2_t = torch.autograd.grad(u2, t2, grad_outputs=torch.ones_like(u2), retain_graph=True, create_graph=True)[0]
        u2_x = torch.autograd.grad(u2, x2, grad_outputs=torch.ones_like(u2), retain_graph=True, create_graph=True)[0]
        u2_tt = torch.autograd.grad(u2_t, t2, grad_outputs=torch.ones_like(u2_t),retain_graph=True, create_graph=True)[0]
        u2_xx = torch.autograd.grad(u2_x, x2, grad_outputs=torch.ones_like(u2_x),retain_graph=True, create_graph=True)[0]

        # Sub-net 3
        u3 = self.net_u(x3, t3, self.weights3, self.biases3)
        u3_t = torch.autograd.grad(u3, t3, grad_outputs=torch.ones_like(u3), retain_graph=True, create_graph=True)[0]
        u3_x = torch.autograd.grad(u3, x3, grad_outputs=torch.ones_like(u3), retain_graph=True, create_graph=True)[0]
        u3_tt = torch.autograd.grad(u3_t, t3, grad_outputs=torch.ones_like(u3_t),retain_graph=True, create_graph=True)[0]
        u3_xx = torch.autograd.grad(u3_x, x3, grad_outputs=torch.ones_like(u3_x),retain_graph=True, create_graph=True)[0]

        # Sub-Net1, Interface 1
        u1i1 = self.net_u(xi1, ti1, self.weights1, self.biases1)
        u1i1_t = torch.autograd.grad(u1i1, ti1, grad_outputs=torch.ones_like(u1i1), retain_graph=True, create_graph=True)[0]
        u1i1_x = torch.autograd.grad(u1i1, xi1, grad_outputs=torch.ones_like(u1i1), retain_graph=True, create_graph=True)[0]
        u1i1_tt = torch.autograd.grad(u1i1_t, ti1, grad_outputs=torch.ones_like(u1i1_t),retain_graph=True, create_graph=True)[0]
        u1i1_xx = torch.autograd.grad(u1i1_x, xi1, grad_outputs=torch.ones_like(u1i1_x),retain_graph=True, create_graph=True)[0]

        # Sub-Net2, Interface 1
        u2i1 = self.net_u(xi1, ti1, self.weights2, self.biases2)
        u2i1_t = torch.autograd.grad(u2i1, ti1, grad_outputs=torch.ones_like(u2i1), retain_graph=True, create_graph=True)[0]
        u2i1_x = torch.autograd.grad(u2i1, xi1, grad_outputs=torch.ones_like(u2i1), retain_graph=True, create_graph=True)[0]
        u2i1_tt = torch.autograd.grad(u2i1_t, ti1, grad_outputs=torch.ones_like(u2i1_t),retain_graph=True, create_graph=True)[0]
        u2i1_xx = torch.autograd.grad(u2i1_x, xi1, grad_outputs=torch.ones_like(u2i1_x),retain_graph=True, create_graph=True)[0]


        # Sub-Net1, Interface 2
        u1i2 = self.net_u(xi2, ti2, self.weights1, self.biases1)
        u1i2_t = torch.autograd.grad(u1i2, ti2, grad_outputs=torch.ones_like(u1i2), retain_graph=True, create_graph=True)[0]
        u1i2_x = torch.autograd.grad(u1i2, xi2, grad_outputs=torch.ones_like(u1i2), retain_graph=True, create_graph=True)[0]
        u1i2_tt = torch.autograd.grad(u1i2_t, ti2, grad_outputs=torch.ones_like(u1i2_t),retain_graph=True, create_graph=True)[0]
        u1i2_xx = torch.autograd.grad(u1i2_x, xi2, grad_outputs=torch.ones_like(u1i2_x),retain_graph=True, create_graph=True)[0]

        # Sub-Net3, Interface 2
        u3i2 = self.net_u(xi2, ti2, self.weights3, self.biases3)
        u3i2_t = torch.autograd.grad(u3i2, ti2, grad_outputs=torch.ones_like(u3i2), retain_graph=True, create_graph=True)[0]
        u3i2_x = torch.autograd.grad(u3i2, xi2, grad_outputs=torch.ones_like(u3i2), retain_graph=True, create_graph=True)[0]
        u3i2_tt = torch.autograd.grad(u3i2_t, ti2, grad_outputs=torch.ones_like(u3i2_t),retain_graph=True, create_graph=True)[0]
        u3i2_xx = torch.autograd.grad(u3i2_x, xi2, grad_outputs=torch.ones_like(u3i2_x),retain_graph=True, create_graph=True)[0]

        # Average value (Required for enforcing the average solution along the interface)
        uavgi1 = (u1i1 + u2i1)/2  
        uavgi2 = (u1i2 + u3i2)/2

        # Residuals
        f1 = u1_xx + u1_tt - (torch.exp(x1) + torch.exp(t1))
        f2 = u2_xx + u2_tt - (torch.exp(x2) + torch.exp(t2))
        f3 = u3_xx + u3_tt - (torch.exp(x3) + torch.exp(t3))

        # Residual continuity conditions on the interfaces
        fi1 = (u1i1_xx + u1i1_tt - (torch.exp(xi1) + torch.exp(ti1))) - (u2i1_xx + u2i1_tt - (torch.exp(xi1) + torch.exp(ti1))) 
        fi2 = (u1i2_xx + u1i2_tt - (torch.exp(xi2) + torch.exp(ti2))) - (u3i2_xx + u3i2_tt - (torch.exp(xi2) + torch.exp(ti2)))

        return   f1, f2, f3, fi1, fi2, uavgi1, uavgi2, u1i1, u1i2, u2i1, u3i2
    
    # Funcrion Loss
    def Loss(self, x, t, u, x1, t1, x2, t2, x3, t3, xi1, ti1, xi2, ti2):

        f1, f2, f3, fi1, fi2, uavgi1, uavgi2, u1i1, u1i2, u2i1, u3i2 = \
            self.net_f(x1, t1, x2, t2, x3, t3, xi1, ti1, xi2, ti2)
        
        loss1 = 20*torch.mean((self.net_u(x, t, self.weights1, self.biases1) - u)**2) + \
            torch.mean(f1**2) + torch.mean(fi1**2) + torch.mean(fi2**2) \
                + 20*torch.mean((u1i1 - uavgi1)**2) + 20*torch.mean((u1i2 - uavgi2)**2)
        
        loss2 = torch.mean(f2**2) + torch.mean(fi1**2) + 20*torch.mean((u2i1 - uavgi1)**2)
        
        loss3 = torch.mean(f3**2) + torch.mean(fi2**2) + 20*torch.mean((u3i2 - uavgi2)**2)
        
        return loss1, loss2, loss3


    def closure(self):

        self.optimizer.zero_grad()
        self.loss1, self.loss2, self.loss3 = self.Loss(self.x, self.t, self.u, self.x1, self.t1, self.x2, self.t2, self.x3, self.t3, \
                         self.xi1, self.ti1, self.xi2, self.ti2)
            
        loss = self.loss1 + self.loss2 + self.loss3

        self.loss_list.append(loss.item())

        if self.iter % 100 == 0:
            print('loss: %.3e' %(loss.item()))
        loss.backward()
        self.iter += 1
        return loss    
        
    def train(self, epoch):

        self.iter = 0        
        self.optimizer_Adam = torch.optim.Adam(self.weights1 + self.biases1 + self.weights2 + self.biases2 + self.weights3 + self.biases3, lr=8e-4)

        for i in range(epoch):
            self.loss1, self.loss2, self.loss3 = self.Loss(self.x, self.t, self.u, self.x1, self.t1, self.x2, self.t2, self.x3, self.t3, \
                         self.xi1, self.ti1, self.xi2, self.ti2)
            
            loss = self.loss1 + self.loss2 + self.loss3
            
            self.optimizer_Adam.zero_grad()
            loss.backward()
            self.optimizer_Adam.step()

            if self.iter % 1 == 0:
                print('Iter:%d, loss1:%.3e, loss2:%.3e, loss3:%.3e'%(i, self.loss1.item(), self.loss2.item(), self.loss2.item()))
        self.optimizer = torch.optim.LBFGS(self.weights1 + self.biases1 + self.weights2 + self.biases2 + self.weights3 + self.biases3, 1, max_iter = 10000, max_eval = None, 
                        tolerance_grad = 1e-11, tolerance_change = 1e-11, history_size = 100, line_search_fn = 'strong_wolfe')
        self.optimizer.step(self.closure)

    def predict(self, x, t):
        x = torch.tensor(x).float().to(self.device)
        t = torch.tensor(t).float().to(self.device)

        u1 = self.net_u(x, t, self.weights1, self.biases1).cpu().detach().numpy()
        u2 = self.net_u(x, t, self.weights2, self.biases2).cpu().detach().numpy()
        u3 = self.net_u(x, t, self.weights3, self.biases3).cpu().detach().numpy()
        return u1, u2, u3


# Boundary points from subdomian 1
N_ub   = 200

# Residual points in three subdomains
N_f1   = 5000
N_f2   = 1800
N_f3   = 1200

# Interface points along the two interfaces
N_I1   = 100
N_I2   = 100

# NN architecture in each subdomain
layers1 = [2, 30, 30, 1]
layers2 = [2, 20, 20, 20, 20, 1]
layers3 = [2, 25, 25, 25, 1]
layers = [layers1, layers2, layers3]

# Load training data (boundary points), residual and interface points from .mat file
# All points are generated in Matlab
data = scipy.io.loadmat('upload/XPINN_2D_PoissonEqn.mat')


x_f1 = data['x_f1'].flatten()[:,None]
y_f1 = data['y_f1'].flatten()[:,None]
x_f2 = data['x_f2'].flatten()[:,None]
y_f2 = data['y_f2'].flatten()[:,None]
x_f3 = data['x_f3'].flatten()[:,None]
y_f3 = data['y_f3'].flatten()[:,None]
xi1  = data['xi1'].flatten()[:,None]
yi1  = data['yi1'].flatten()[:,None]
xi2  = data['xi2'].flatten()[:,None]
yi2  = data['yi2'].flatten()[:,None]
xb   = data['xb'].flatten()[:,None]
yb   = data['yb'].flatten()[:,None]


ub_train  = data['ub'].flatten()[:,None]
u_exact = data['u_exact'].flatten()[:,None]
u_exact2 = data['u_exact2'].flatten()[:,None]
u_exact3 = data['u_exact3'].flatten()[:,None]

X_f1_train = np.hstack((x_f1.flatten()[:,None], y_f1.flatten()[:,None]))
X_f2_train = np.hstack((x_f2.flatten()[:,None], y_f2.flatten()[:,None]))
X_f3_train = np.hstack((x_f3.flatten()[:,None], y_f3.flatten()[:,None]))

X_fi1_train = np.hstack((xi1.flatten()[:,None], yi1.flatten()[:,None]))
X_fi2_train = np.hstack((xi2.flatten()[:,None], yi2.flatten()[:,None]))


X_ub_train = np.hstack((xb.flatten()[:,None], yb.flatten()[:,None]))

# Points in the whole  domain
x_total =  data['x_total'].flatten()[:,None] 
y_total =  data['y_total'].flatten()[:,None]

X_star1 = np.hstack((x_f1.flatten()[:,None], y_f1.flatten()[:,None]))
X_star2 = np.hstack((x_f2.flatten()[:,None], y_f2.flatten()[:,None]))
X_star3 = np.hstack((x_f3.flatten()[:,None], y_f3.flatten()[:,None]))

# Randomly select the residual points from sub-domains
idx1 = np.random.choice(X_f1_train.shape[0], N_f1, replace=False)    
X_f1_train = X_f1_train[idx1,:]

idx2 = np.random.choice(X_f2_train.shape[0], N_f2, replace=False)    
X_f2_train = X_f2_train[idx2,:]

idx3 = np.random.choice(X_f3_train.shape[0], N_f3, replace=False)    
X_f3_train = X_f3_train[idx3,:]

# Randomly select boundary points
idx4 = np.random.choice(X_ub_train.shape[0], N_ub, replace=False)
X_ub_train = X_ub_train[idx4,:]
ub_train   = ub_train[idx4,:] 

# Randomly select the interface points along two interfaces
idxi1 = np.random.choice(X_fi1_train.shape[0], N_I1, replace=False)    
X_fi1_train = X_fi1_train[idxi1,:]

idxi2 = np.random.choice(X_fi2_train.shape[0], N_I2, replace=False)    
X_fi2_train = X_fi2_train[idxi2,:]


model = XPINNs(X_ub_train ,ub_train,X_f1_train,X_f2_train,X_f3_train,\
                              X_fi1_train, X_fi2_train, layers)


model.train(000)


# Solution prediction
u_pred1, _, _ = model.predict(X_star1[:, 0:1], X_star1[:, 1:2])
_, u_pred2, _ = model.predict(X_star2[:, 0:1], X_star2[:, 1:2])
_, _, u_pred3 = model.predict(X_star3[:, 0:1], X_star3[:, 1:2])
        
# Needed for plotting
X1, Y1 = X_star1[:,0:1], X_star1[:,1:2]
X2, Y2 = X_star2[:,0:1], X_star2[:,1:2]
X3, Y3 = X_star3[:,0:1], X_star3[:,1:2]

# Concatenating the solution from subdomains
u_pred = np.concatenate([u_pred1, u_pred2, u_pred3])

error_u_total = np.linalg.norm(np.squeeze(u_exact)-u_pred.flatten(),2)/np.linalg.norm(np.squeeze(u_exact),2)
print('Error u_total: %e' % (error_u_total))


u1 = u_exact[:u_pred1.shape[0]]
u2 = u_exact[u_pred1.shape[0]: u_pred1.shape[0]+u_pred2.shape[0]]
u3 = u_exact[ u_pred1.shape[0]+u_pred2.shape[0]: u_pred1.shape[0]+u_pred2.shape[0] + u_pred3.shape[0]]


import matplotlib
fig = plt.figure(figsize=(20, 5))
norm = matplotlib.colors.Normalize(vmin=0, vmax=8)


plt.subplot(131)
plt.scatter(X1, Y1, c=u_pred1, cmap='rainbow', norm=norm)
plt.scatter(X2, Y2, c=u_pred2, cmap='rainbow', norm=norm)
plt.scatter(X3, Y3, c=u_pred3, cmap='rainbow', norm=norm)
plt.xlabel('x')
plt.ylabel('y')
plt.colorbar()

plt.subplot(132)
plt.scatter(X1, Y1, c=u1, cmap='rainbow', norm=norm)
plt.scatter(X2, Y2, c=u2, cmap='rainbow', norm=norm)
plt.scatter(X3, Y3, c=u3, cmap='rainbow', norm=norm)
plt.xlabel('x')
plt.ylabel('y')
plt.colorbar()

plt.subplot(133)
plt.scatter(X1, Y1, c=np.abs(u_pred1 - u1), cmap='rainbow')
plt.scatter(X2, Y2, c=np.abs(u_pred2 - u2), cmap='rainbow')
plt.scatter(X3, Y3, c=np.abs(u_pred3 - u3), cmap='rainbow')
plt.xlabel('x')
plt.ylabel('y')
plt.colorbar()


plt.suptitle("2D Possion error:%.3e"%(error_u_total), fontsize=20)
plt.show()


plt.show()


torch.save([[model.weights1, model.biases1], [model.weights2, model.biases2], [model.weights3, model.biases3]], "./checkpoints/model.pt")




