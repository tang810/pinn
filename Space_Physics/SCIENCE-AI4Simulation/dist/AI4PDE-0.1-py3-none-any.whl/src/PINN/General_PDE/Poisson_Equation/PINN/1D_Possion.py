import torch
import numpy as np
import matplotlib.pyplot as plt
import os
import sys

sys.path.append(os.path.dirname(os.getcwd()))

from scr.net import PINNs
from scr.data import data

device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')
torch.manual_seed(1234)
np.random.seed(1234)

## 继承PINNs 并自定义方程
class PINN(PINNs):

    def Loss_PDE(self, x):
        u = self.forward(x)
        u_x = torch.autograd.grad(u, x, grad_outputs=torch.ones_like(u), retain_graph=True, create_graph=True)[0]
        u_xx = torch.autograd.grad(u_x, x, grad_outputs=torch.ones_like(u), retain_graph=True, create_graph=True)[0]
        return u_xx - self.solutionD(x)
    
    def solutionD(self, x):
        return -1.6 * torch.pi**2 * torch.sin(4*torch.pi*x) - 50*sech(5*x)**2 * torch.tanh(5*x)

## 继承data，并自定义精确解
class get_data(data):

    def solution(self, x):
        return 0.1*torch.sin(4 * torch.pi * x) + torch.tanh(5*x)
    
    
## 辅助用的函数
def sech(x):
    if torch.is_tensor(x):
        return 2/(torch.exp(x) + torch.exp(-x))
    else:
        return 2/(np.exp(x) + np.exp(-x))


layers = [1] + [20]*1 +[1]                  ## 网络
lb, ub = [-1], [1]                          ## 边界
N_f, N_u = 100, 2                           ## 数据量

data_sampler = get_data(lb, ub)                 ## 定义采样器
X_f, X_u, u = data_sampler.sample(N_f, N_u)     ## 获取数据


model = PINN(X_f, X_u, u,  layers,lb, ub)       ## 定义模型
model.train(1000)                              ## 训练



## plot ##
def solution(x):
    return 0.1*np.sin(4 * np.pi * x) + np.tanh(5*x)


x = np.linspace(lb[0], ub[0], 100).reshape(-1, 1)
t = solution(x)
y = model.predict(x)
error_u = np.linalg.norm(y-t,2)/np.linalg.norm(t,2) 
print('error_u: %.3e' % (error_u))

palette = plt.get_cmap('Set1')
y = model.predict(x)

plt.figure(figsize=(16,5))
plt.subplot(1,2,1)
plt.plot(x, t, color="black", label="exact")
plt.scatter(x, y, color=palette(0), marker="*", label="predict")
plt.legend()

plt.subplot(1,2,2)
plt.plot(x, np.abs(y-t), color=palette(1), label="error")
plt.legend()

plt.suptitle("1D Possion error:%.3e"%(error_u), fontsize=20)


plt.show()






