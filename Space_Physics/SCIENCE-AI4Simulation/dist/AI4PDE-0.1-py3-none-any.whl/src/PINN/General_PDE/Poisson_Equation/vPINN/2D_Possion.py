import torch
import numpy as np
import matplotlib.pyplot as plt
import os
import sys

sys.path.append(os.path.dirname(os.getcwd()))

from scr.net import PINNs
from scr.data import data
import scr.Variational_function as var

device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')
torch.manual_seed(1234)
np.random.seed(1234)


## 继承PINNs 并自定义方程，并自定义损失函数
class PINN(PINNs):

    ## 这里修改输入， 并初始化一些需要用到的数据
    def __init__(self, X_q, W_q, X_u, u, layers, lb, ub, device=torch.device("cpu")):
        X_f = X_q

        super(PINN, self).__init__(X_f, X_u, u, layers, lb, ub, device, activation=torch.nn.Tanh)

        ## 勒让德权重、方程的测试函数，fx的测试函数
        self.w_q = W_q
        self.test_matrix_1, self.test_matrix_2 =  test_matrix_1[0].to(device), test_matrix_1[1].to(device)
        self.dtest_matrix_1, self.dtest_matrix_2 = dtest_matrix[0].to(device),  dtest_matrix[1].to(device)
        self.d2test_matrix_1, self.d2test_matrix_2 = d2test_matrix[0].to(device),  d2test_matrix[1].to(device)

        self.test_matrix_fx_1, self.test_matrix_fx_2 =  test_matrix_2[0].to(device), test_matrix_2[1].to(device)

    ## 自定义损失
    def Loss_PDE(self, x):
        u = self.forward(x)
        u_x_y = torch.autograd.grad(u, x, grad_outputs=torch.ones_like(u), retain_graph=True, create_graph=True)[0]
        u_x, u_y = u_x_y[:, 0:1], u_x_y[:, 1:2]

        u_xx_xy = torch.autograd.grad(u_x, x, grad_outputs=torch.ones_like(u_x), retain_graph=True, create_graph=True)[0]
        u_yx_yy = torch.autograd.grad(u_y, x, grad_outputs=torch.ones_like(u_x), retain_graph=True, create_graph=True)[0]
        u_xx, u_yy = u_xx_xy[:, 0:1], u_yx_yy[:, 1:2]
        

        ## 变分第一种， 具体公式看论文 这个最好使
        if variation_form == 0:
            f = u_xx + u_yy

            F1 = torch.mm((self.w_q[:, 0:1]*self.test_matrix_1*f).T,  self.w_q[:, 1:2]*self.test_matrix_2)
            F2 = torch.mm((self.w_q[:, 0:1]*self.test_matrix_fx_1*self.solutionD(x)).T,  self.w_q[:, 1:2]*self.test_matrix_fx_2)
            return F1 - F2
        ## 变分第二种， 误差较大
        if variation_form == 1:
            F1 = torch.mm((self.w_q[:, 0:1]*self.dtest_matrix_1*u_x).T,  self.w_q[:, 1:2]*self.test_matrix_2)
            F2 = torch.mm((self.w_q[:, 0:1]*self.test_matrix_1*u_y).T,  self.w_q[:, 1:2]*self.dtest_matrix_2)
            F3 = torch.mm((self.w_q[:, 0:1]*self.test_matrix_fx_1*self.solutionD(x)).T,  self.w_q[:, 1:2]*self.test_matrix_fx_2)
            return -(F1 + F2) - F3

        ## 变分第三种，目前这个不好使
        if variation_form == 2:
            F1 = torch.mm((self.w_q[:, 0:1]*self.d2test_matrix_1*u).T,  self.w_q[:, 1:2]*self.test_matrix_2)
            F2 = torch.mm((self.w_q[:, 0:1]*self.test_matrix_1*u).T,  self.w_q[:, 1:2]*self.d2test_matrix_2)
            F3 = torch.mm((self.w_q[:, 0:1]*self.test_matrix_fx_1*self.solutionD(x)).T,  self.w_q[:, 1:2]*self.test_matrix_fx_2)

            return F1 + F2 - F3
    
    def solutionD(self, x):
        return torch.exp(x[:, 0:1]) + torch.exp(x[:, 1:2])

## 继承data，并自定义精确解
class get_data(data):

    def solution(self, x, y):
        return torch.exp(x) + torch.exp(y)


## 网络
layers = [2] + [40]*2 +[1]
## 边界
lb, ub = [0, 0], [1, 1]
## 数据量
N_q, N_t, N_u = [20, 20], [10, 10], 200
## 变分形式
variation_form = 0                      ## 仅支持形式 0, 1, 2

## 定义采样器
data_sampler = get_data(lb, ub)
## 获取数据
X_u, u = data_sampler.get_boundry_2D(N_u)


## 获取勒让德积分点， 权重， 测试函数，
var_data_sampler = var.var_data(lb, ub)
X_q, W_q, test_matrix_1, test_matrix_2 = var_data_sampler(N_q, N_t, 0)

## 测试函数的导数形式
_, _, dtest_matrix, _ = var_data_sampler(N_q, N_t, 1)
_, _, d2test_matrix, _ = var_data_sampler(N_q, N_t, 2)


## 变分形式第三种所需要的边界数据
x_boundry = torch.tensor([lb[0], ub[0]]).reshape(-1, 1)
y_boundry = torch.tensor([lb[1], ub[1]]).reshape(-1, 1)

## 边界数据测试函数的导数形式
dtest_x_boundry = torch.cat([var_data_sampler.Legendre_polynomials(i, 1, x_boundry) for i in range(1, N_t[0]+1)], dim=1)
dtest_y_boundry = torch.cat([var_data_sampler.Legendre_polynomials(i, 1, y_boundry) for i in range(1, N_t[1]+1)], dim=1)

## 积分以后有个负号
res_dtest_x_boundry = (- dtest_x_boundry[0:1, :] + dtest_x_boundry[1:2, :] ).reshape(-1, 1)
res_dtest_y_boundry = (- dtest_y_boundry[0:1, :] + dtest_y_boundry[1:2, :] ).reshape(-1, 1)



model = PINN(X_q, W_q, X_u, u, layers, lb, ub,)
model.train(1000)





## plot ##
def solution(x, y):
    return np.exp(x) + np.exp(y)

x, t = np.meshgrid(np.linspace(lb[0], ub[0], 100), np.linspace(lb[1], ub[1], 100))
x, t = x.reshape(-1, 1), t.reshape(-1, 1)

u_pred = model.predict(np.hstack([x, t])).reshape(100, 100)
u = solution(x, t).reshape(100, 100)

x, t = x.reshape(100, 100), t.reshape(100, 100)

error_u = np.linalg.norm(u - u_pred, 2) / np.linalg.norm(u, 2) 
print('error_u: %.3e' % (error_u))



fig = plt.figure(figsize=(20, 5))
plt.subplot(131)
plt.imshow(u_pred, interpolation='nearest', cmap='rainbow',origin='lower', aspect='auto')
plt.colorbar()
plt.title("prediction")

plt.subplot(132)
plt.imshow(u, interpolation='nearest', cmap='rainbow',origin='lower', aspect='auto')
plt.colorbar()
plt.title("Exact")


plt.subplot(133)
plt.imshow(np.abs(u_pred - u), interpolation='nearest', cmap='rainbow',origin='lower', aspect='auto')
plt.colorbar()
plt.title("Error")

plt.suptitle("2D Possion error:%.3e"%(error_u), fontsize=20)
plt.show()


