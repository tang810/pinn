import torch
import numpy as np
import matplotlib.pyplot as plt
import os
import sys

sys.path.append(os.path.dirname(os.getcwd()))

from scr.net import PINNs
from scr.data import data

device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')
torch.manual_seed(1234)
np.random.seed(1234)


## 继承PINNs 并自定义方程
class PINN(PINNs):

    def Loss_PDE(self, x):
        u = self.forward(x)
        u_x_y = torch.autograd.grad(u, x, grad_outputs=torch.ones_like(u), retain_graph=True, create_graph=True)[0]
        u_x, u_y = u_x_y[:, 0:1], u_x_y[:, 1:2]

        u_xx_xy = torch.autograd.grad(u_x, x, grad_outputs=torch.ones_like(u_x), retain_graph=True, create_graph=True)[0]
        u_yx_yy = torch.autograd.grad(u_y, x, grad_outputs=torch.ones_like(u_x), retain_graph=True, create_graph=True)[0]
        u_xx, u_yy = u_xx_xy[:, 0:1], u_yx_yy[:, 1:2]

        u_xxx_xxy = torch.autograd.grad(u_xx, x, grad_outputs=torch.ones_like(u_x), retain_graph=True, create_graph=True)[0]
        u_yyx_yyy = torch.autograd.grad(u_yy, x, grad_outputs=torch.ones_like(u_x), retain_graph=True, create_graph=True)[0]
        u_xxx, u_xxy, u_yyx, u_yyy = u_xxx_xxy[:, 0:1],u_xxx_xxy[:, 1:2], u_yyx_yyy[:, 0:1], u_yyx_yyy[:, 1:2]

        return u_xx + u_yy - self.solutionD(x[:, 0:1], x[:, 1:2]), u_xxx + u_yyx - self.solutionD(x[:, 0:1], x[:, 1:2]), u_xxy + u_yyy - self.solutionD(x[:, 0:1], x[:, 1:2])
    
    def solutionD(self, x, y):
        return torch.exp(x) + torch.exp(y)

## 继承data，并自定义精确解
class get_data(data):

    def solution(self, x, y):
        return torch.exp(x) + torch.exp(y)

## 网络
layers = [2] + [40]*2 +[1]
## 边界
lb, ub = [0, 0], [1, 1]
## 数据量
N_f, N_u = 500, 200


## 定义采样器
data_sampler = get_data(lb, ub)
## 获取数据
X_f, X_u, u = data_sampler.sample(N_f, N_u)


## 定义模型
model = PINN(X_f, X_u, u, layers, lb, ub)
## 训练
model.train(1000)






## plot ##
def solution(x, y):
    return np.exp(x) + np.exp(y)

# import matplotlib
# vnorm = matplotlib.colors.Normalize(vmin=-1, vmax=1)

x, t = np.meshgrid(np.linspace(lb[0], ub[0], 100), np.linspace(lb[1], ub[1], 100))
x, t = x.reshape(-1, 1), t.reshape(-1, 1)

u_pred = model.predict(np.hstack([x, t])).reshape(100, 100)
u = solution(x, t).reshape(100, 100)

x, t = x.reshape(100, 100), t.reshape(100, 100)

error_u = np.linalg.norm(u - u_pred, 2) / np.linalg.norm(u, 2) 
print('error_u: %.3e' % (error_u))



fig = plt.figure(figsize=(20, 5))
plt.subplot(131)
plt.imshow(u_pred, interpolation='nearest', cmap='rainbow',origin='lower', aspect='auto')
plt.colorbar()
plt.title("prediction")

plt.subplot(132)
plt.imshow(u, interpolation='nearest', cmap='rainbow',origin='lower', aspect='auto')
plt.colorbar()
plt.title("Exact")


plt.subplot(133)
plt.imshow(np.abs(u_pred - u), interpolation='nearest', cmap='rainbow',origin='lower', aspect='auto')
plt.colorbar()
plt.title("Error")

plt.suptitle("2D Possion error:%.3e"%(error_u), fontsize=20)
plt.show()



