import torch
import numpy as np
import matplotlib.pyplot as plt
import os
import sys

sys.path.append(os.path.dirname(os.getcwd()))

from scr.net import PINNs
from scr.data import data
import scr.Variational_function as var

device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')
torch.manual_seed(1234)
np.random.seed(1234)


## 继承PINNs 并自定义方程，并自定义损失函数
class PINN(PINNs):

    ## 这里修改输入， 并初始化一些需要用到的数据
    def __init__(self, X_q, W_q,  X_u, u, layers, lb, ub, device=torch.device("cpu")):
        X_f = X_q
        super(PINN, self).__init__(X_f, X_u, u, layers, lb, ub, device, activation=torch.nn.Tanh)

        ## 勒让德权重、方程的测试函数，fx的测试函数
        self.w_q, self.test_matrix_equation, self.test_matrix_fx = W_q.to(device), test_matrix_1[0].T.to(device), test_matrix_2[0].T.to(device)

        ## 变分形式第三种所需要的边界数据
        self.x_boundry = torch.cat([self.lb, self.ub], dim=0).reshape(-1, 1).to(device).requires_grad_()

        ## 边界的测试函数数据
        self.test_matrix_boundray_1, self.test_matrix_boundray_2 = test_matrix_boundray_1[0].T.to(device), test_matrix_boundray_2[0].T.to(device)

    ## 自定义损失
    def Loss_PDE(self, x):
        u = self.forward(x)
        u_x = torch.autograd.grad(u, x, grad_outputs=torch.ones_like(u), retain_graph=True, create_graph=True)[0]
        u_xx = torch.autograd.grad(u_x, x, grad_outputs=torch.ones_like(u), retain_graph=True, create_graph=True)[0]
        
        ## 变分第一种， 具体公式看论文
        if variation_form == 0:
            f = u_xx
            return (torch.mm(self.test_matrix_equation, self.w_q * f) - torch.mm(self.test_matrix_fx, self.w_q * self.solutionD(x)))
        
        ## 变分第二种
        if variation_form == 1:
            f = u_x
            
            u_boundry = self.forward(self.x_boundry)
            u_x_boundry = torch.autograd.grad(u_boundry, self.x_boundry, grad_outputs=torch.ones_like(u_boundry), retain_graph=True, create_graph=True)[0]
            return -(torch.mm(self.test_matrix_equation, self.w_q * f) + torch.mm(self.test_matrix_fx, self.w_q * self.solutionD(x))) + torch.mm(test_matrix_boundray_1[0].T, u_x_boundry)
        
        ## 变分第三种
        if variation_form == 2:
            f = u
            u_boundry = self.forward(self.x_boundry)
            u_x_boundry = torch.autograd.grad(u_boundry, self.x_boundry, grad_outputs=torch.ones_like(u_boundry), retain_graph=True, create_graph=True)[0]

            # return (torch.mm(self.test_matrix_equation, self.w_q * f) - torch.mm(self.test_matrix_fx, self.w_q * self.solutionD(x))) - torch.mm(test_matrix_boundray_1[0].T, u_x_boundry) + torch.mm(test_matrix_boundray_2[0].T, u_boundry)
            return (torch.mm(self.test_matrix_equation, self.w_q * f) - torch.mm(self.test_matrix_fx, self.w_q * self.solutionD(x))) - torch.mm(test_matrix_boundray_2[0].T, u_boundry)
    
    def solutionD(self, x):
        return -1.6 * torch.pi**2 * torch.sin(4*torch.pi*x) - 50*sech(5*x)**2 * torch.tanh(5*x)


## 继承data，并自定义精确解
class get_data(data):

    def solution(self, x):
        return 0.1*torch.sin(4 * torch.pi * x) + torch.tanh(5*x)
    

## 辅助用的函数
def sech(x):
    if torch.is_tensor(x):
        return 2/(torch.exp(x) + torch.exp(-x))
    else:
        return 2/(np.exp(x) + np.exp(-x))


## 网络
layers = [1] + [40]*2 +[1]
## 边界
lb, ub = [-1], [1]
## 数据量
N_q, N_t, N_u = [100], [50], 2
## 变分形式
variation_form = 2                      ## 仅支持形式 0, 1, 2

## 定义采样器
data_sampler = get_data(lb, ub)
## 获取数据
X_u, u = data_sampler.get_boundry_1D(N_u)


## 获取勒让德积分点， 权重， 测试函数， 
var_data_sampler = var.var_data(lb, ub)
X_q, W_q, test_matrix_1, test_matrix_2 = var_data_sampler(N_q, N_t, variation_form)

## 边界的测试函数数值
test_matrix_boundray_1, test_matrix_boundray_2 = var_data_sampler.get_test_matrix(N_t, torch.tensor([lb, ub]).reshape(-1, 1), diff_1=0, diff_2=1)
## 积分以后有个负号
test_matrix_boundray_2[0][0:1] = - test_matrix_boundray_2[0][0:1]



## 定义模型
model = PINN(X_q, W_q,  X_u, u, layers, lb, ub)
## 训练
model.train(1000)





## plot ##
def solution(x):
    return 0.1*np.sin(4 * np.pi * x) + np.tanh(5*x)


x = np.linspace(lb[0], ub[0], 100).reshape(-1, 1)
t = solution(x)
y = model.predict(x)
error_u = np.linalg.norm(y-t,2)/np.linalg.norm(t,2) 
print('error_u: %.3e' % (error_u))

palette = plt.get_cmap('Set1')
y = model.predict(x)

plt.figure(figsize=(16,5))
plt.subplot(1,2,1)
plt.plot(x, t, color="black", label="exact")
plt.scatter(x, y, color=palette(0), marker="*", label="predict")
plt.legend()

plt.subplot(1,2,2)
plt.plot(x, np.abs(y-t), color=palette(1), label="error")
plt.legend()

plt.suptitle("1D Possion error:%.3e"%(error_u), fontsize=20)


plt.show()



