import torch
import torch.nn as nn
import numpy as np
import os
from collections import OrderedDict

# Define a deep neural network (DNN) class
class DNN(nn.Module):
    def __init__(self, layers):
        super(DNN, self).__init__()

        # Create a list to hold the layers of the network
        layer_list = list()
        for i in range(len(layers) - 2):
            # Add a linear layer
            layer_list.append(('layer_%d' % i, nn.Linear(layers[i], layers[i + 1])))
            # Add an activation function (Tanh)
            layer_list.append(('activation_%d' % i, nn.Tanh()))

        # Add the final linear layer
        layer_list.append(('layer_%d' % (len(layers) - 2), nn.Linear(layers[-2], layers[-1])))
        layerDict = OrderedDict(layer_list)

        # Deploy layers using nn.Sequential
        self.layers = nn.Sequential(layerDict)

    def forward(self, x):
        # Define the forward pass through the network
        out = self.layers(x)
        return out


# Define the Physics-Informed Neural Network (PINN) class
class PhysicsInformedNN():
    def __init__(self, X, E, f, layers):
        # Convert input data to PyTorch tensors and enable gradient computation
        self.t = torch.tensor(X[:, 0:1], requires_grad=True).float().to(device)
        self.x = torch.tensor(X[:, 1:2], requires_grad=True).float().to(device)
        self.v = torch.tensor(X[:, 2:3], requires_grad=True).float().to(device)
        self.E = torch.tensor(E).float().to(device)
        self.f = torch.tensor(f).float().to(device)

        # Initialize lambda parameters for the PDE
        self.lambda_1 = torch.tensor([0.0], requires_grad=True).to(device)
        self.lambda_2 = torch.tensor([0.0], requires_grad=True).to(device)
        self.lambda_1 = torch.nn.Parameter(self.lambda_1)
        self.lambda_2 = torch.nn.Parameter(self.lambda_2)

        # Initialize the deep neural network
        self.dnn = DNN(layers).to(device)
        self.dnn.register_parameter('lambda_1', self.lambda_1)
        self.dnn.register_parameter('lambda_2', self.lambda_2)

        # Initialize the optimizer (Adam)
        self.optimizer = torch.optim.Adam(self.dnn.parameters())
        self.iter = 0

    def net_f(self, t, x, v):
        # Concatenate input tensors and pass them through the DNN to get f and E
        result = self.dnn(torch.cat([t, x, v], dim=1))
        f = result[:, 0:1]
        E = result[:, 1:2]
        return f, E

    def net_g(self, t, x, v):
        # Compute the residual of the PDE
        lambda_1 = self.lambda_1
        lambda_2 = self.lambda_2
        f, E = self.net_f(t, x, v)
        f_t = torch.autograd.grad(f, t, grad_outputs=torch.ones_like(f), retain_graph=True, create_graph=True)[0]
        f_x = torch.autograd.grad(f, x, grad_outputs=torch.ones_like(f), retain_graph=True, create_graph=True)[0]
        f_v = torch.autograd.grad(f, v, grad_outputs=torch.ones_like(f), retain_graph=True, create_graph=True)[0]

        # PDE: f_t + v * f_x - E * f_v = 0
        # Complete form: f_t + v * f_x - (e/m) * E * f_v = 0, where (e/m) = 1
        g = f_t + lambda_1 * v * f_x + lambda_2 * E * f_v
        return g

    def train(self, nIter):
        # Train the model
        self.dnn.train()
        for epoch in range(nIter):
            # Forward pass to compute predictions and PDE residual
            f_pred, E_pred = self.net_f(self.t, self.x, self.v)
            g_pred = self.net_g(self.t, self.x, self.v)

            # Compute losses
            loss_f = torch.mean((self.f - f_pred) ** 2)  # Mean squared error for f
            loss_E = torch.mean((self.E - E_pred) ** 2)  # Mean squared error for E
            loss_g = torch.mean((g_pred) ** 2)  # Mean squared error for PDE residual

            # Total loss: alpha * loss_g + beta * loss_f + gamma * loss_E
            alpha, beta, gamma = (1, 1, 1)
            loss = alpha * loss_g + beta * loss_f + gamma * loss_E

            # Log the training loss
            with open(os.path.join(save_path, "train_loss.txt"), "a") as f:
                f.write('%.6e' % (loss.item()) + "\n")

            # Backward pass and optimization
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()

            # Print training progress
            if epoch % 100 == 0:
                print(
                    'Epoch: %d, Loss: %.6e, Lambda_1: %.6f, Lambda_2: %.6f' %
                    (
                        epoch,
                        loss.item(),
                        self.lambda_1.item(),
                        self.lambda_2.item()
                    )
                )

            # Save the model periodically
            if epoch % 20000 == 0:
                torch.save(self.dnn.state_dict(), os.path.join(save_path, "PINN_" + str(epoch) + ".pth"))

        # Save the final model
        torch.save(self.dnn.state_dict(), os.path.join(save_path, "PINN_final.pth"))

    def load_model(self, path):
        # Load a pre-trained model
        self.dnn.load_state_dict(torch.load(path))

    def predict(self, T_star, X_star, V_star):
        # Predict f and E using the trained model
        f, E = self.net_f(T_star, X_star, V_star)
        f = f.detach().cpu().numpy()
        E = E.detach().cpu().numpy()
        return f, E


if __name__ == "__main__":
    # Set the save path for model checkpoints and logs
    save_path = r"./Result/"
    if not os.path.exists(save_path):
        os.mkdir(save_path)

    # Determine the device (GPU if available, otherwise CPU)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # Load data from files
    N_u = 70000
    layers = [3, 50, 50, 50, 50, 50, 50, 50, 50, 2]
    E = np.load("./E.npy")
    f = np.load("./f.npy")
    t_range = (0, 101)
    x_range = (0, 257)
    v_range = (0, 257)
    t = np.linspace(0, 62.5, E.shape[0])[t_range[0]:t_range[1]]
    x = np.linspace(0, 10, 257)[x_range[0]:x_range[1]]
    v = np.linspace(-5, 5, 257)[v_range[0]:v_range[1]]
    E = np.swapaxes(E, 1, 2)[t_range[0]:t_range[1], x_range[0]:x_range[1], v_range[0]:v_range[1]]
    f = np.swapaxes(f, 1, 2)[t_range[0]:t_range[1], x_range[0]:x_range[1], v_range[0]:v_range[1]]

    # Prepare the training data using meshgrid
    T, X, V = np.meshgrid(t, x, v)
    T = np.swapaxes(T, 0, 1)
    X = np.swapaxes(X, 0, 1)
    V = np.swapaxes(V, 0, 1)

    X_star = np.hstack((T.flatten()[:, None], X.flatten()[:, None], V.flatten()[:, None]))  # t,x,v
    f_star = f.flatten()[:, None]

    # Create the training set
    idx = np.random.choice(X_star.shape[0], N_u, replace=False)
    X_u_train = X_star[idx, :]
    idx_on_tx = np.unravel_index(idx, f.shape)  # return index in tx space
    E_train = E[idx_on_tx[0], idx_on_tx[1]]
    f_train = f_star[idx, :]

    # Set the number of training iterations and training flag
    step = 200000
    train = True

    if train:
        # Initialize and train the model
        model = PhysicsInformedNN(X_u_train, E_train, f_train, layers)
        model.train(step)
    else:
        # Load the model and make predictions
        model = PhysicsInformedNN(X_u_train, E_train, f_train, layers)
        model.load_model("PINN_final.pth")
        T_star = torch.tensor(T.flatten()[:, None]).float().to(device)
        X_star = torch.tensor(X.flatten()[:, None]).float().to(device)
        V_star = torch.tensor(V.flatten()[:, None]).float().to(device)

        f_pred, E_pred = model.predict(T_star, X_star, V_star)

        # Reshape predictions to match the original data shape
        f_pred = np.reshape(f_pred, f.shape)
        E_pred = np.reshape(E_pred, E.shape)

        # Plotting the results using matplotlib
        import matplotlib.pyplot as plt

        tru = f[80, 80, :]
        pre = f_pred[80, 80, :]
        v = np.linspace(-5, 5, 257)[v_range[0]:v_range[1]]
        plt.plot(v, tru, label="truth")
        plt.plot(v, pre, label="prediction")
        plt.xlim(-5, 5)
        plt.ylim(-0.05, 0.6)
        plt.xlabel("Velocity")
        plt.ylabel("Normalized Velocity Distribution Function")
        plt.legend()
        plt.show()