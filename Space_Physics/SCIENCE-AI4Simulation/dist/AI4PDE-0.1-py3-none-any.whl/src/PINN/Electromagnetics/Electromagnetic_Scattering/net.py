import deepxde as dde

def build_model(data, num_layers, num_nodes, activation, output_transform):
    net = dde.maps.FNN([2] + [num_nodes] * num_layers + [2], activation, "Glorot normal")
    net.apply_output_transform(output_transform)
    model = dde.Model(data, net)
    return model
