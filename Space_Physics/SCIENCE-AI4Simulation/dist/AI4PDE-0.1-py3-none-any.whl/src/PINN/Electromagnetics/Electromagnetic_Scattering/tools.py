import numpy as np
from deepxde.geometry import Rectangle

def generate_geometry(length, dpml):
    outer = Rectangle([-length / 2 - dpml, -length / 2 - dpml], [length / 2 + dpml, length / 2 + dpml])
    return outer

def output_transform(inputs, outputs, BOX, dpml):
    x, y = inputs[:, 0:1], inputs[:, 1:2]
    a_y, b_y = BOX[0][1] - dpml, BOX[1][1] + dpml
    a_x, b_x = BOX[0][0] - dpml, BOX[1][0] + dpml
    return (1 - np.exp(a_y - y)) * (1 - np.exp(y - b_y)) * \
           (1 - np.exp(a_x - x)) * (1 - np.exp(x - b_x)) * outputs
