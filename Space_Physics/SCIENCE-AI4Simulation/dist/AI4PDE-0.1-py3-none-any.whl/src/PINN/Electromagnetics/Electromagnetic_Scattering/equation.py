import torch
import numpy as np

SIGMA0 = -np.log(1e-20) / (4 * 1 ** 3 / 3)
OMEGA = 2.0944  # 波数

def PML(X, BOX):
    def sigma(x, a, b):
        def _sigma(d):
            return SIGMA0 * d ** 2 * torch.where(d > 0, torch.ones_like(d), torch.zeros_like(d))
        return _sigma(a - x) + _sigma(x - b)

    def dsigma(x, a, b):
        def _sigma(d):
            return 2 * SIGMA0 * d * torch.where(d > 0, torch.ones_like(d), torch.zeros_like(d))
        return -_sigma(a - x) + _sigma(x - b)

    sigma_x = sigma(X[:, :1], BOX[0][0], BOX[1][0])
    AB1 = 1 / (1 + 1j / OMEGA * sigma_x) ** 2
    A1, B1 = AB1.real, AB1.imag

    dsigma_x = dsigma(X[:, :1], BOX[0][0], BOX[1][0])
    AB2 = -1j / OMEGA * dsigma_x * AB1 / (1 + 1j / OMEGA * sigma_x)
    A2, B2 = AB2.real, AB2.imag

    sigma_y = sigma(X[:, 1:], BOX[0][1], BOX[1][1])
    AB3 = 1 / (1 + 1j / OMEGA * sigma_y) ** 2
    A3, B3 = AB3.real, AB3.imag

    dsigma_y = dsigma(X[:, 1:], BOX[0][1], BOX[1][1])
    AB4 = -1j / OMEGA * dsigma_y * AB3 / (1 + 1j / OMEGA * sigma_y)
    A4, B4 = AB4.real, AB4.imag

    return A1, B1, A2, B2, A3, B3, A4, B4

def pde(inputs, outputs, eps, k0, BOX):
    A1, B1, A2, B2, A3, B3, A4, B4 = PML(inputs, BOX)

    dReE_x = torch.autograd.grad(outputs[:, 0:1], inputs, grad_outputs=torch.ones_like(outputs[:, 0:1]), create_graph=True)[0][:, 0:1]
    dReE_y = torch.autograd.grad(outputs[:, 0:1], inputs, grad_outputs=torch.ones_like(outputs[:, 0:1]), create_graph=True)[0][:, 1:2]
    dReE_xx = torch.autograd.grad(dReE_x, inputs, grad_outputs=torch.ones_like(dReE_x), create_graph=True)[0][:, 0:1]
    dReE_yy = torch.autograd.grad(dReE_y, inputs, grad_outputs=torch.ones_like(dReE_y), create_graph=True)[0][:, 1:2]

    dImE_x = torch.autograd.grad(outputs[:, 1:2], inputs, grad_outputs=torch.ones_like(outputs[:, 1:2]), create_graph=True)[0][:, 0:1]
    dImE_y = torch.autograd.grad(outputs[:, 1:2], inputs, grad_outputs=torch.ones_like(outputs[:, 1:2]), create_graph=True)[0][:, 1:2]
    dImE_xx = torch.autograd.grad(dImE_x, inputs, grad_outputs=torch.ones_like(dImE_x), create_graph=True)[0][:, 0:1]
    dImE_yy = torch.autograd.grad(dImE_y, inputs, grad_outputs=torch.ones_like(dImE_y), create_graph=True)[0][:, 1:2]

    ReE = outputs[:, 0:1]
    ImE = outputs[:, 1:2]

    loss_Re = A1 * dReE_xx + A2 * dReE_x + A3 * dReE_yy + A4 * dReE_y - \
              (B1 * dImE_xx + B2 * dImE_x + B3 * dImE_yy + B4 * dImE_y) + eps * k0 ** 2 * ReE
    loss_Im = A1 * dImE_xx + A2 * dImE_x + A3 * dImE_yy + A4 * dImE_y + \
              (B1 * dReE_xx + B2 * dReE_x + B3 * dReE_yy + B4 * dReE_y) + eps * k0 ** 2 * ImE

    return loss_Re, loss_Im
