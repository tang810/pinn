import deepxde as dde
import numpy as np
from tools import generate_geometry, output_transform
from equation import pde
from net import build_model

# 参数设置
length, dpml, nx = 3, 1, 50
BOX = np.array([[-length / 2, -length / 2], [length / 2, length / 2]])
k0 = 2.0944
eps = 4.0

# 几何体生成
geom = generate_geometry(length, dpml)

# 数据定义
data = dde.data.PDE(
    geom,
    lambda x, y: pde(x, y, eps=eps, k0=k0, BOX=BOX),
    [],
    num_domain=nx ** 2 * 6,
    num_boundary=8 * nx * 6,
)

# 输出转换函数
def custom_output_transform(inputs, outputs):
    return output_transform(inputs, outputs, BOX, dpml)

# 模型定义
model = build_model(data, num_layers=5, num_nodes=50, activation="tanh", output_transform=custom_output_transform)

# 训练
model.compile("adam", lr=0.001)
losshistory, train_state = model.train(iterations=10000)

# 切换到 L-BFGS-B 优化
model.compile("L-BFGS-B")
losshistory, train_state = model.train()

# 保存和可视化
dde.saveplot(losshistory, train_state, issave=True, isplot=True)
