import deepxde as dde
from data import geom
from net import create_network, transform_inverse
from pinn import pde_inverse

# 定义优化参数（初始值）
param = dde.Variable(0.5)  # 例如目标形状参数（半径）

# 定义边界条件
bcs = []  # 可根据问题定义边界条件

# 定义数据集
data = dde.data.PDE(
    geom,
    lambda inputs, outputs: pde_inverse(inputs, outputs, [param]),
    bcs,
    num_domain=1024,
    num_boundary=128,
)

# 定义神经网络
net = create_network()
net.apply_output_transform(lambda x, y: transform_inverse(x, y, [param]))

# 训练模型
model = dde.Model(data, net)
model.compile("adam", lr=0.001)
losshistory, train_state = model.train(epochs=10000)

# 输出优化结果
print(f"优化后的目标参数: R = {param.value}")
dde.saveplot(losshistory, train_state, issave=True, isplot=False)
