import deepxde as dde
from data import PML, eps0, k0


def pde_inverse(inputs, outputs, params):
    """定义逆散射问题的PDE"""
    A1, B1, A2, B2 = PML(inputs)

    ReE = outputs[:, 0:1]
    ImE = outputs[:, 1:2]
    dReE_xx = dde.grad.hessian(outputs, inputs, component=0, i=0, j=0)
    dReE_yy = dde.grad.hessian(outputs, inputs, component=0, i=1, j=1)
    dImE_xx = dde.grad.hessian(outputs, inputs, component=1, i=0, j=0)
    dImE_yy = dde.grad.hessian(outputs, inputs, component=1, i=1, j=1)

    eps_pred = params[0]  # 目标介电常数
    loss_Re = A1 * dReE_xx + A2 * dReE_yy - eps_pred * k0**2 * ReE
    loss_Im = A1 * dImE_xx + A2 * dImE_yy - eps_pred * k0**2 * ImE

    return loss_Re, loss_Im
