import deepxde as dde
import numpy as np
import torch

# 问题参数
k0 = 2.0944  # 波数
R = 0.5  # 初始猜测的目标半径
DPML = 1  # PML层厚度
SIGMA0 = -np.log(1e-20) / (4 * DPML**3 / 3)  # PML强度
OMEGA = k0
length = 3  # 总区域长度
eps0 = 1.0  # 背景介电常数

# 几何定义
outer = dde.geometry.Rectangle(
    [-length / 2 - DPML, -length / 2 - DPML], [length / 2 + DPML, length / 2 + DPML]
)
inner = dde.geometry.Disk([0, 0], R)
geom = outer - inner

