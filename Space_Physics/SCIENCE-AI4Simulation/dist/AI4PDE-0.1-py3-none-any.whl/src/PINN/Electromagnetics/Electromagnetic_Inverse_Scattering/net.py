import deepxde as dde
import torch


def create_network(num_layers=5, num_nodes=50, activation="tanh"):
    """定义神经网络结构"""
    return dde.maps.FNN([2] + [num_nodes] * num_layers + [2], activation, "Glorot normal")


def transform_inverse(x, y, params):
    """将网络输出与目标参数相关联，用于表示目标形状"""
    R_pred = params[0]  # 优化目标参数，例如目标半径
    dist_square = x[:, 0:1]**2 + x[:, 1:2]**2
    res = dist_square - R_pred**2
    return res * y
