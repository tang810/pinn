import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import matplotlib.pyplot as plt
from read_data import load_mat
from test_calculate import ciou_problem
import os, math
from net import DenoisingAutoencoder, MagneticMomentNet, CombinedModel
from sklearn.model_selection import train_test_split
from tqdm import tqdm
from pykalman import KalmanFilter

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")  # Run on CPU


def kalman_filter(data):
    kf = KalmanFilter(n_dim_obs=3, n_dim_state=3)
    kf.x = np.array([1, 1, 1])
    kf = kf.em(data, n_iter=10)
    state_means, _ = kf.smooth(data)
    return state_means


def read_objstatus(path):
    data = load_mat(path)
    measurepoint = data['measurepoint'][0, 0]
    L_ship = data['L'][0, 0]
    W_ship = data['W'][0, 0]
    M = data['M'][0, 0]
    theta = data['dpsi'][0, 0]
    x_vals = torch.tensor(measurepoint[:, 0], dtype=torch.float32).to(device)
    y_vals = torch.tensor(measurepoint[:, 1], dtype=torch.float32).to(device)
    # z_vals = torch.tensor(measurepoint[:, 2], dtype=torch.float32).to(device)
    L_ship, W_ship = torch.tensor(L_ship, dtype=torch.float32).to(device), torch.tensor(W_ship, dtype=torch.float32).to(
        device)
    return x_vals, y_vals, theta, L_ship, W_ship


# 读取带噪声的信号
def generate_data(path, ship=False):
    data = load_mat(path)
    B_noise = data['Mag_NED'][0, 0].T
    B_noise_kalman = kalman_filter(B_noise)
    measurepoint = data['measurepoint'][0, 0]
    L = data['L'][0, 0]
    W = data['W'][0, 0]
    M = data['M'][0, 0]
    theta = data['dpsi'][0, 0]
    x_vals = torch.tensor(measurepoint[:, 0], dtype=torch.float32).to(device)
    y_vals = torch.tensor(measurepoint[:, 1], dtype=torch.float32).to(device)
    z_vals = torch.tensor(measurepoint[:, 2], dtype=torch.float32).to(device)
    L, W = torch.tensor(L, dtype=torch.float32).to(device), torch.tensor(W, dtype=torch.float32).to(device)
    m_input = torch.tensor(M, dtype=torch.float32).to(device)
    # 调用函数
    if ship:
        B_clean = ciou_problem(x_vals, y_vals, theta, L, W, z_vals, m_input, M=15, ellN=True).detach().cpu().numpy()
    else:
        B_clean = ciou_problem(x_vals, y_vals, theta, L, W, z_vals, m_input, M=5, ellN=False).detach().cpu().numpy()
    obj_status = {"x_vals": x_vals,
                  "y_vals": y_vals,
                  "theta": theta,
                  "L": L,
                  "W": W,
                  "z_vals": z_vals}
    # print(B_clean.type)
    # B_clean = torch.tensor(B_clean,dtype=torch.float32)
    # B_noise = torch.tensor(B_noise,dtype=torch.float32)
    return B_clean, B_noise_kalman, obj_status


# 使用训练好的模型进行去噪
def denoise_signal(model, noisy_signal):
    noisy_signal = torch.tensor(noisy_signal, dtype=torch.float32)
    denoised_signal = model(noisy_signal)
    return denoised_signal.detach().numpy()


def magnetic_loss(pred_m, true_B, obj_status, z_vals):
    # true_B = torch.tensor(true_B,dtype=torch.float32)
    # m_output = torch.tan(pred_m)
    ## pred_m shape:[1,30]
    m_reshape = pred_m.view(-1, 2)  ## shape:[1,30]
    ind = m_reshape[:, 0]
    val = m_reshape[:, 1]
    m_output = (10 ** ind) * val
    # import pdb
    # pdb.set_trace()
    x_vals, y_vals, theta, L, W = obj_status["x_vals"], obj_status["y_vals"], obj_status["theta"], obj_status["L"], \
    obj_status["W"]
    pred_B = ciou_problem(x_vals, y_vals, theta, L, W, z_vals, m_output, M=5, ellN=False)
    # pred_B = torch.tan(pred)
    loss = torch.mean((pred_B[:, 0:1] - true_B[:, 0:1]) ** 2 +
                      (pred_B[:, 1:2] - true_B[:, 1:2]) ** 2 +
                      (pred_B[:, 2:3] - true_B[:, 2:3]) ** 2)

    return loss


if __name__ == "__main__":
    # 生成数据
    # path = '/save/magnetic/test_1206/data_1206/Dataset2/Sweeper/Emulate_large_ship,L=112m,W=0.8m,rz0=20m,ry0=60m,dpsi=3.1416rad,V=5ms,SNR=0dB.mat'
    Sweeper_path = '/save/magnetic/test_1206/data_1206/Dataset2/Sweeper'
    Ship_path = '/save/magnetic/test_1206/data_1206/Dataset2/Ship'
    all_clean_ship_signals = []
    all_noisy_ship_signals = []
    all_clean_sweeper_signals = []
    all_noisy_sweeper_signals = []
    all_obj_ship_status = []
    ## ship
    for file in tqdm(os.listdir(Ship_path)[:100]):  # [:5]:#[:100]:#[:5]:#[:10]:
        clean_ship_signal, noisy_ship_signal, obj_ship_status = generate_data(os.path.join(Ship_path, file), ship=True)
        # print(f'clean_signal.shape{clean_signal.shape}')
        all_clean_ship_signals.append(clean_ship_signal)
        all_noisy_ship_signals.append(noisy_ship_signal)
        all_obj_ship_status.append(obj_ship_status)
    print(f'ship_path_len:{len(os.listdir(Ship_path))}')
    # print(len(all_clean_ship_signals))
    train_ship_clean, test_ship_clean, train_ship_noisy, test_ship_noisy, train_ship_obj, test_ship_obj = train_test_split(
        all_clean_ship_signals, all_noisy_ship_signals, all_obj_ship_status, test_size=0.4, random_state=42)

    ## sweeper
    all_obj_sweeper_status = []
    for file in tqdm(os.listdir(Sweeper_path)[:100]):  # [:5]:#[:100]:#[:5]:#[:10]:
        clean_sweeper_signal, noisy_sweeper_signal, obj_sweeper_status = generate_data(os.path.join(Sweeper_path, file),
                                                                                       ship=False)
        # print(f'clean_signal.shape{clean_signal.shape}')
        all_clean_sweeper_signals.append(clean_sweeper_signal)
        all_noisy_sweeper_signals.append(noisy_sweeper_signal)
        all_obj_sweeper_status.append(obj_sweeper_status)
    print(f'sweeper_path_len:{len(os.listdir(Sweeper_path))}')
    # print(len(all_clean_sweeper_signals))
    # 划分训练集和测试集
    train_sweeper_clean, test_sweeper_clean, train_sweeper_noisy, test_sweeper_noisy, train_sweeper_obj, test_sweeper_obj = train_test_split(
        all_clean_sweeper_signals, all_noisy_sweeper_signals, all_obj_sweeper_status, test_size=0.4, random_state=42)
    train_clean = train_ship_clean + train_sweeper_clean
    test_clean = test_ship_clean + test_sweeper_clean
    train_noisy = train_ship_noisy + train_sweeper_noisy
    test_noisy = test_ship_noisy + test_sweeper_noisy
    train_obj = train_ship_obj + train_sweeper_obj

    # ## 转换成tensor
    # from torch.nn.utils.rnn import pad_sequence

    # 转换为张量列表
    train_clean = [torch.tensor(x, dtype=torch.float32).to(device) for x in train_clean]
    test_clean = [torch.tensor(x, dtype=torch.float32).to(device) for x in test_clean]
    train_noisy = [torch.tensor(x, dtype=torch.float32).to(device) for x in train_noisy]
    test_noisy = [torch.tensor(x, dtype=torch.float32).to(device) for x in test_noisy]
    # train_clean_padded = pad_sequence(train_clean_tensors, batch_first=True, padding_value=0.0)
    # print(train_clean_tensors.shape)
    # print(train_clean_padded.shape)
    # # 对其他数据进行相同处理
    # test_clean_tensors = [torch.tensor(x, dtype=torch.float32) for x in test_clean]
    # test_clean_padded = pad_sequence(test_clean_tensors, batch_first=True, padding_value=0.0)

    # test_clean_tensors = [torch.tensor(x, dtype=torch.float32) for x in test_clean]
    # test_clean_padded = pad_sequence(test_clean_tensors, batch_first=True, padding_value=0.0)

    # train_clean = torch.tensor(train_clean,dtype=torch.float32)
    # test_clean = torch.tensor(test_clean,dtype=torch.float32)
    # train_noisy = torch.tensor(train_noisy,dtype=torch.float32)
    # test_noisy = torch.tensor(test_noisy,dtype=torch.float32)

    # 输出训练集和测试集的大小
    print(f"训练集样本数: {len(train_clean)}")
    print(f"测试集样本数: {len(test_clean)}")
    print(f"测试集obj样本数: {len(train_obj)}")

    # 训练模型
    # 模型初始化
    layers = [3, 128, 256, 512, 256, 128, 30]
    lr = 0.01
    epochs = 20000
    # autoencoder = DenoisingAutoencoder(input_dim=3).to(device)
    # magneticnet = MagneticMomentNet(layers).to(device)
    # model = CombinedModel(autoencoder, magneticnet).to(device)

    model = MagneticMomentNet(layers).to(device)

    # 损失函数和优化器

    optimizer = optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-3)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min',
                                                     factor=0.9, patience=10000)
    # scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=100, gamma=0.9)
    ## 保存模型路径
    save_path = './model_result/PINN'
    os.makedirs(save_path, exist_ok=True)
    # 训练模型
    for epoch in tqdm(range(epochs)):
        model.train()
        optimizer.zero_grad()

        # 前向传播
        for i in range(len(train_noisy)):
            pred_m = model(train_noisy[i])
            # import pdb
            # pdb.set_trace()

            m_reshape = pred_m.view(-1, 2)  ## shape:[1,30]
            ind = m_reshape[:, 0]
            val = m_reshape[:, 1]

            # print(f'train_noisy[i].shape:{train_noisy[i].shape}')
            # print(f'pred_m.shape:{pred_m.shape}')

            # 计算两个损失
            # loss_denoising = criterion_denoising(denoised_output, train_clean[i])
            z_vals = train_obj[i]["z_vals"]
            loss_new = magnetic_loss(pred_m, train_clean[i], train_obj[i],
                                     z_vals=z_vals)  # magnetic_loss(pred_m,true_B,obj_status,z_vals)
            # pdb.set_trace()
            # import pdb
            # pdb.set_trace()
            # 总损失
            # loss = 1000*loss_denoising + 0*loss_new
            loss = loss_new

            # 后向传播和优化
            loss.backward()
            optimizer.step()
            scheduler.step(loss)

        print(
            f"Epoch [{epoch}/{epochs}], Loss: {loss.item():.4f}, lr: {optimizer.param_groups[0]['lr']}"  # , ind:{ind}, "
            # f"Denoising Loss: {loss_denoising.item():.4f}, "
            f"solve Loss: {loss_new.item():.4f}")
        if epoch % 10 == 0:
            torch.save(model.state_dict(), os.path.join(save_path, f'savedmodel_{epoch}.pth'))

    # 使用模型
    model.eval()
    with torch.no_grad():
        # denoised_output, new_output = model(test_noisy)
        pred_m = model(test_noisy)

    # 打印预测结果
    # print("Denoised Signal (first 5):")
    # print(denoised_output[:5].numpy())
    print("Predicted Target (first 5):")
    print(pred_m.numpy())
    # print("True Target (first 5):")
    # print([:5].numpy())
    # 使用训练好的模型去噪
    # denoised_signal = denoise_signal(model, test_noisy)

    # # # 绘制结果
    # # plt.figure(figsize=(10, 8))

    # # 绘制第一维信号
    # plt.subplot(3, 1, 1)
    # plt.plot(test_clean[:, 0], label="Clean Signal (dim 1)")
    # plt.plot(test_noisy[:, 0], label="Noisy Signal (dim 1)", alpha=0.5)
    # plt.plot(denoised_signal[:, 0], label="Denoised Signal (dim 1)", linestyle='--')
    # plt.legend()
    # plt.title("Signal Dimension 1")

    # # 绘制第二维信号
    # plt.subplot(3, 1, 2)
    # plt.plot(test_clean[:, 1], label="Clean Signal (dim 2)")
    # plt.plot(test_noisy[:, 1], label="Noisy Signal (dim 2)", alpha=0.5)
    # plt.plot(denoised_signal[:, 1], label="Denoised Signal (dim 2)", linestyle='--')
    # plt.legend()
    # plt.title("Signal Dimension 2")

    # # 绘制第三维信号
    # plt.subplot(3, 1, 3)
    # plt.plot(test_clean[:, 2], label="Clean Signal (dim 3)")
    # plt.plot(test_noisy[:, 2], label="Noisy Signal (dim 3)", alpha=0.5)
    # plt.plot(denoised_signal[:, 2], label="Denoised Signal (dim 3)", linestyle='--')
    # plt.legend()
    # plt.title("Signal Dimension 3")

    # plt.tight_layout()
    # plt.show()
    # plt.savefig('denoise.png')

