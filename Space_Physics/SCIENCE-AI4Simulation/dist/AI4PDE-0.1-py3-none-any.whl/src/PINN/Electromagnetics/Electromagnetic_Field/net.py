import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import math
from collections import OrderedDict
# neural network
class MagneticMomentNet(torch.nn.Module):
    def __init__(self, layers,
                 #activation=torch.nn.LeakyReLU):
                 activation=torch.nn.SiLU):
        super(MagneticMomentNet, self).__init__()
        # parameters
        self.depth = len(layers) - 1
        # set up layer order dict
        self.activation = activation

        layer_list = list()
        for i in range(self.depth - 1):
            layer_list.append(
                ('layer_%d' % i, torch.nn.Linear(layers[i], layers[i + 1]))
            )
            layer_list.append(('activation_%d' % i, self.activation()))

        layer_list.append(
            ('layer_%d' % (self.depth - 1), torch.nn.Linear(layers[-2], layers[-1]))
        )
        layerDict = OrderedDict(layer_list)

        # deploy layers
        self.layers = torch.nn.Sequential(layerDict)

    def forward(self, x):
        # 原始网络输出
        out = self.layers(x)
        # 应用 Tanh 激活并缩放到 (-π/2, π/2)
        # out = torch.tanh(out) * (torch.pi / 2)
        # 聚合批次输出到 [1, 15]
        out = torch.mean(out, dim=0, keepdim=True)  # [1, 15]
        return out

# 定义降噪自编码器模型
class DenoisingAutoencoder(nn.Module):
    def __init__(self, input_dim):
        super(DenoisingAutoencoder, self).__init__()
        # 编码器部分
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, 16),
            nn.ReLU()
        )
        # 解码器部分
        self.decoder = nn.Sequential(
            nn.Linear(16, 32),
            nn.ReLU(),
            nn.Linear(32, 64),
            nn.ReLU(),
            nn.Linear(64, input_dim)
        )
    
    def forward(self, x):
        encoded = self.encoder(x)
        decoded = self.decoder(encoded)
        return decoded


# 联合模型
class CombinedModel(nn.Module):
    def __init__(self, autoencoder, new_network):
        super(CombinedModel, self).__init__()
        self.autoencoder = autoencoder
        self.new_network = new_network
    
    def forward(self, x):
        # 自编码器的去噪输出
        denoised_output = self.autoencoder(x)
        # 使用去噪后的信号作为新网络的输入
        new_output = self.new_network(denoised_output)
        return denoised_output, new_output

