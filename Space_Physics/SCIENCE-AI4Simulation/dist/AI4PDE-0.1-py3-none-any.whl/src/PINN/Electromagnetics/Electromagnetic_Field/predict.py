import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import matplotlib.pyplot as plt
from read_data import load_mat
from test_calculate import ciou_problem
import os,math
from net import DenoisingAutoencoder,MagneticMomentNet,CombinedModel
from sklearn.model_selection import train_test_split
from denoise import generate_data
import pandas as pd
device = torch.device("cuda" if torch.cuda.is_available() else "cpu") # Run on CPU

def pred_m(model,path,save_path):
    pred_m_all = []
    for file in os.listdir(path):
        # print(file)
        test_noisy = generate_data(os.path.join(path,file),clean=False)

        test_noisy = torch.tensor(test_noisy,dtype=torch.float32).to(device)
        
        # 使用模型
        model.eval()
        with torch.no_grad():
            pred_m = model(test_noisy).detach().cpu().numpy()
        # print(path.split("/")[-1])
    
        # 提取第二列和第三列
        cols = pred_m[:, 1:3]  # 形状为 (6, 2)
        # print(cols.shape)
        # 检查是否所有值都介于 [-1, 1] 之间
        condition = (cols >= -1) & (cols <= 1)
        all_values_in_range = condition.all()
        if all_values_in_range:
            ty = "Sweeper"
        else:
            ty = "Ship"
        pred_m_all.append({'文件': file,
                            'mx': pred_m[:,0],
                            'my': pred_m[:,1],
                            'mz': pred_m[:,2],
                            '正确类别': path.split("/")[-1],
                            '判断类别': ty})
    df = pd.DataFrame(pred_m_all)
    df.to_csv(save_path,index=False,encoding='utf-8')
    return df

if __name__ == "__main__":
    # path = '/save/magnetic/test_1206/data_1206/Dataset2/Sweeper/Emulate_large_ship,L=112m,W=0.8m,rz0=20m,ry0=60m,dpsi=3.1416rad,V=5ms,SNR=0dB.mat'
    # path = '/save/magnetic/test_1206/Large_ship_model,L=152.96m,W=17.28m,dipN=15,ellN=1,rz0=20m,ry0=0m,dpsi=0rad,V=15ms,SNR=30dB.mat'
    # test_clean, test_noisy,obj_status = generate_data(path,ship=False)
    Sweeper_path = '/save/magnetic/test_1206/data_1206/Dataset2/Sweeper'
    Ship_path = '/save/magnetic/test_1206/data_1206/Dataset2/Ship'
    save_path = './pred_m/'
    os.makedirs(save_path,exist_ok=True)
    pred_m_ship = []
    save_ship_path = 'ship.csv'
    save_sweeper_path = 'sweeper.csv'

    layers = [3,128,256,512,256,128,18]

    model = MagneticMomentNet(layers).to(device)
    state_dict = torch.load('/save/magnetic/test_1206/model_result/PINN/savedmodel_270.pth',weights_only=True)
    model.load_state_dict(state_dict)
    pred_m(model,Ship_path,save_path=os.path.join(save_path,save_ship_path))
    pred_m(model,Sweeper_path,save_path=os.path.join(save_path,save_sweeper_path))
    # print(Sweeper_path.split("/")[-1])

    
        # print(f'pred_m:{pred_m.view(-1,3)}')
    # # 使用模型
    # model.eval()
    # with torch.no_grad():
        # denoised_output, new_output = model(test_noisy)

    # test_noisy_np = test_noisy.detach().cpu().numpy()
    # denoised_output, new_output = denoised_output.detach().cpu().numpy(), new_output.detach().cpu().numpy()

    # # 绘制结果
    # plt.figure(figsize=(10, 8))

    # # 绘制第一维信号
    # plt.subplot(3, 1, 1)
    # plt.plot(test_clean[:, 0], label="Clean Signal (dim 1)")
    # plt.plot(test_noisy_np[:, 0], label="Noisy Signal (dim 1)", alpha=0.5)
    # plt.plot(denoised_output[:, 0], label="Denoised Signal (dim 1)", linestyle='--')
    # plt.legend()
    # plt.title("Signal Dimension 1")

    # # 绘制第二维信号
    # plt.subplot(3, 1, 2)
    # plt.plot(test_clean[:, 1], label="Clean Signal (dim 2)")
    # plt.plot(test_noisy_np[:, 1], label="Noisy Signal (dim 2)", alpha=0.5)
    # plt.plot(denoised_output[:, 1], label="Denoised Signal (dim 2)", linestyle='--')
    # plt.legend()
    # plt.title("Signal Dimension 2")

    # # 绘制第三维信号
    # plt.subplot(3, 1, 3)
    # plt.plot(test_clean[:, 2], label="Clean Signal (dim 3)")
    # plt.plot(test_noisy_np[:, 2], label="Noisy Signal (dim 3)", alpha=0.5)
    # plt.plot(denoised_output[:, 2], label="Denoised Signal (dim 3)", linestyle='--')
    # plt.legend()
    # plt.title("Signal Dimension 3")


    # plt.tight_layout()
    # plt.show()
    # save_path = 'test_result'
    # os.makedirs(save_path,exist_ok=True)
    # plt.savefig(os.path.join(save_path,'denoise.png'))