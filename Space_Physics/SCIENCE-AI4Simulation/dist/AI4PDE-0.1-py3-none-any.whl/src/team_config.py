# -*- coding: utf-8 -*-
import os
import re
import sys
import asyncio
import subprocess
import tempfile
import io
import base64
import json
import requests
import logging
import traceback

from typing import List, Dict, Tuple, Optional
from sentence_transformers import CrossEncoder
import numpy as np
from fastapi.concurrency import run_in_threadpool
import uuid
from alpha.team import Team
from alpha.roles import Role
from alpha.logs import logger
from alpha.schema import Message
from alpha.actions import Action, UserRequirement

from src.llm_utils import SeLLM
from src.llm_utils import load_config

from dotenv import load_dotenv
load_dotenv()
handler = {"sink": sys.stdout, "level": "ERROR"}
logger.configure(handlers=[handler])

from src.oss_utils import download_to_file, oss_upload_by_path, get_image_url

os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "max_split_size_mb:10240"

# 读取环境变量
server_base = os.getenv('server_base')
config = load_config("config/config.yaml")
backend_url = config["BACKEND_URL"]
source_path = config['SOURCE_CODE_PATH']
#backend_url = os.getenv('BACKEND_URL', 'http://www.science42.vip:40300')

base_dir = '/mnt/sdb/anaconda3/envs/ResponsibleProgramming/lib/python3.10/site-packages/src'
########################################
# 工具函数
########################################

# 修改正则，提取所有 python 代码块
CODE_BLOCK_PATTERN = re.compile(
    r"```python(.*?)```",
    re.DOTALL | re.IGNORECASE
)

def extract_all_python_codes(text: str) -> list:
    """
    从文本中提取所有 ```python ... ``` 代码块。
    如果找不到，则返回空列表。
    """
    return [code.strip() for code in CODE_BLOCK_PATTERN.findall(text)]

async def run_code_in_jupyter(code: str, user_name: str, timeout: int = 60) -> dict:
    """
    在Jupyter notebook中运行代码并处理返回结果，添加超时机制
    改进处理多种输出类型的能力（图片和文本可以同时存在）
    
    :param code: 要执行的代码
    :param user_name: 用户名
    :param timeout: 超时时间（秒），默认60秒
    :return: 包含执行状态和结果的字典
    """
    try:
        # 准备数据
        data = {
            "code": code,
            "user_name": user_name
        }
        print('data:{}'.format(data))
        
        # 使用 wait_for 添加超时机制
        try:
            response = await asyncio.wait_for(
                run_in_threadpool(
                    lambda: requests.post(f"{backend_url}/api/v1/jupyter_run", data=data)
                ),
                timeout=timeout
            )
        except asyncio.TimeoutError:
            print(f"执行超过 {timeout} 秒，已取消")
            return {"status": "error", "error": f"代码执行超时（超过 {timeout} 秒）"}
        
        # 处理响应
        result = response.json()
        print('jupyter results:{}'.format(result))
        
        # 处理返回的消息
        if 'message' in result:
            # 首先检查是否有错误信息
            for msg in result['message']:
                if isinstance(msg, dict) and (
                    'traceback' in msg or 'ename' in msg or 'evalue' in msg
                ):
                    print("检测到执行错误")
                    # 构建错误消息
                    error_components = []
                    
                    # 添加 traceback
                    if 'traceback' in msg and isinstance(msg['traceback'], list):
                        error_components.append('\n'.join(msg['traceback']))
                    elif 'traceback' in msg:
                        error_components.append(str(msg['traceback']))
                    
                    # 添加错误名称和值
                    if 'ename' in msg and 'evalue' in msg:
                        error_components.append(f"{msg['ename']}: {msg['evalue']}")
                    elif 'ename' in msg:
                        error_components.append(str(msg['ename']))
                    elif 'evalue' in msg:
                        error_components.append(str(msg['evalue']))
                    
                    # 组合错误信息
                    error_text = '\n'.join(error_components)
                    print(f"错误信息: {error_text[:100]}...")
                    return {"status": "error", "error": error_text}
            
            # 收集所有输出
            all_outputs = []
            has_output = False
            
            # 检查消息结构可能有多种情况
            for msg in result['message']:
                # 处理字典形式的消息
                if isinstance(msg, dict):
                    # 处理包含data的消息
                    if 'data' in msg:
                        # 处理图像数据
                        if 'image/png' in msg['data']:
                            base64_img = msg['data']['image/png']
                            # 构造完整的base64图像字符串
                            img_data = f"data:image/png;base64,{base64_img}"
                            all_outputs.append({"type": "image", "content": img_data})
                            has_output = True
                        
                        # 处理文本数据
                        if 'text/plain' in msg['data'] and msg['data']['text/plain'].strip():
                            all_outputs.append({"type": "text", "content": msg['data']['text/plain']})
                            has_output = True
                    
                    # 处理直接包含text的消息
                    elif 'text' in msg and msg['text'].strip():
                        all_outputs.append({"type": "text", "content": msg['text']})
                        has_output = True
                    
                    # 处理直接包含type和content的消息
                    elif 'type' in msg and msg['type'] == 'text' and 'content' in msg:
                        all_outputs.append({"type": "text", "content": msg['content']})
                        has_output = True
                
                # 处理字符串形式的消息
                elif isinstance(msg, str) and msg.strip():
                    all_outputs.append({"type": "text", "content": msg})
                    has_output = True
            
            if has_output:
                return {"status": "success", "output": all_outputs}
            else:
                return {"status": "success", "output": []}
        
        else:
            return {"status": "error", "error": "无效的返回格式"}
    
    except Exception as e:
        error_detail = str(e)
        return {"status": "error", "error": error_detail}

async def run_code(code: str, user_name: str, websocket) -> (str, str):
    """
    统一的代码执行接口，处理同时包含图片和文本的输出
    """
    try:
        result = await run_code_in_jupyter(code, user_name)
        print('run code result:{}'.format(result))
        
        if result.get('status') == 'success':
            output = result.get('output', [])
            
            # 对于websocket，发送完整输出（包括图片）
            output_str_for_user = ""
            for item in output:
                if item['type'] == 'image':
                    if websocket:
                        await websocket.send_text(f"\n![image]({item['content']})\n")
                    output_str_for_user += f"![image]({item['content']})\n"
                elif item['type'] == 'text':
                    if websocket:
                        await websocket.send_text(f"\n```\n{item['content']}\n```\n")
                    output_str_for_user += f"```\n{item['content']}\n```\n"
            
            # 对于LLM，准备不含base64数据的版本
            output_str_for_llm = ""
            for item in output:
                if item['type'] == 'image':
                    output_str_for_llm += "[图片输出已生成]\n"
                elif item['type'] == 'text':
                    output_str_for_llm += f"```\n{item['content']}\n```\n"
            
            return output_str_for_llm, ''  # 返回给LLM的版本
        else:
            error = result.get('error', '执行出错')
            if websocket:
                await websocket.send_text(f"\n```\nError:\n{error}\n```\n")
            return '', error
            
    except Exception as e:
        error_msg = f"代码执行出错：{str(e)}"
        if websocket:
            await websocket.send_text(f"\n```\nError:\n{error_msg}\n```\n")
        return '', error_msg

import os
import json
import traceback
import numpy as np
from typing import Tuple, Optional, List, Dict, Any
from sentence_transformers.cross_encoder import CrossEncoder

class CodeRetriever:
    """
    负责检索代码文件的类，使用 reranker 模型并增强文件描述的上下文
    """
    def __init__(self, 
                json_file_path: str = "./tools/ai4pde_structure.json",
                reranker_model_path: str = "/mnt/sdb/bge/bge-reranker-large",
                score_threshold: float = 0.55):
        """
        初始化代码检索器
        
        Args:
            json_file_path: 代码结构JSON文件的路径
            reranker_model_path: reranker模型的路径
            score_threshold: 匹配得分阈值，低于此值视为不匹配
        """
        self.json_file_path = json_file_path
        self.reranker_model_path = reranker_model_path
        self.score_threshold = score_threshold
        self.code_files = []  # 存储解析后的代码文件信息
        self.directory_info = {}  # 存储目录信息
        
        # 加载 reranker 模型
        try:
            self.reranker = CrossEncoder(reranker_model_path)
            print(f"成功加载 reranker 模型: {reranker_model_path}")
        except Exception as e:
            print(f"加载 reranker 模型失败: {str(e)}")
            raise
        
        # 解析代码结构文件
        self._parse_json_file()
        
        # 增强文件描述的上下文
        self._enhance_file_descriptions()
    
    def _parse_json_file(self):
        """
        解析 ai4pde_structure.json 文件，提取代码文件路径、描述以及目录结构信息
        """
        try:
            # 确保使用正确的JSON文件路径
            if not os.path.exists(self.json_file_path):
                print(f"警告: 代码结构JSON文件不存在: {self.json_file_path}")
                return
            
            with open(self.json_file_path, "r", encoding="utf-8") as f:
                structure_data = json.load(f)
            
            # 清空现有数据
            self.code_files = []
            self.directory_info = {}
            
            # 基础路径
            #base_dir = "/home/suser/se42/ximu_science/responsible_programming/src"
            
            # 递归处理模块结构
            def process_modules(modules, parent_path=""):
                for module in modules:
                    name = module.get("name", "")
                    path = module.get("path", "")
                    description = module.get("description", "")
                    
                    # 构建完整路径
                    full_path = os.path.join(base_dir, path)
                    
                    # 判断是否为代码文件（.py 或 .ipynb 结尾）
                    is_code_file = name.endswith('.py') or name.endswith('.ipynb')
                    
                    # 更新目录信息
                    if not is_code_file:
                        dir_path = path
                        if dir_path not in self.directory_info:
                            self.directory_info[dir_path] = {
                                "description": description,
                                "files": []
                            }
                        
                        # 如果是README.md，更新父目录的描述
                        if name.endswith('README.md') or name.endswith('Readme.md'):
                            parent_dir = os.path.dirname(path)
                            if parent_dir in self.directory_info:
                                self.directory_info[parent_dir]["description"] = description
                    
                    # 构建文件信息
                    file_info = {
                        "name": name,
                        "file_path": path,
                        "full_path": full_path,
                        "description": description,
                        "is_code_file": is_code_file
                    }
                    
                    # 如果是代码文件，添加到代码文件列表
                    if is_code_file:
                        self.code_files.append(file_info)
                    
                    # 如果有子模块，递归处理
                    if "submodules" in module and module["submodules"]:
                        process_modules(module["submodules"], path)
                    
                    # 如果有文件列表，处理文件
                    if "files" in module and module["files"]:
                        process_modules(module["files"], path)
            
            # 开始处理模块
            if "modules" in structure_data:
                process_modules(structure_data["modules"])
            else:
                print("警告: JSON文件中没有找到'modules'键")
            
            # 打印解析结果统计
            print(f"已解析 {len(self.code_files)} 个代码文件及其描述")
            print(f"已解析 {len(self.directory_info)} 个目录结构")
            
            # 打印前几个文件路径用于调试
            print("\n前5个解析的文件路径:")
            for i, file_info in enumerate(self.code_files[:5]):
                print(f"{i+1}. {file_info['file_path']} -> {file_info['full_path']}")
                
        except Exception as e:
            print(f"解析代码结构JSON文件时出错: {str(e)}")
            traceback.print_exc()
            raise
        
    def _enhance_file_descriptions(self):
        """
        增强文件描述的上下文，包含目录信息和相关文件信息
        """
        for i, file_info in enumerate(self.code_files):
            if not file_info["is_code_file"]:
                continue
                
            # 调试：检查 description 是否为字符串
            if not isinstance(file_info["description"], str):
                print(f"警告: 文件 {file_info['file_path']} 的描述不是字符串而是 {type(file_info['description'])}: {file_info['description']}")
                file_info["description"] = str(file_info["description"])  # 转换为字符串
                
            enhanced_description = file_info["description"]
            context_parts = []
            
            # 1. 添加文件所在目录的描述
            dir_path = os.path.dirname(file_info["file_path"])
            if dir_path in self.directory_info:
                # 调试：检查目录描述是否为字符串
                if not isinstance(self.directory_info[dir_path]["description"], str):
                    print(f"警告: 目录 {dir_path} 的描述不是字符串而是 {type(self.directory_info[dir_path]['description'])}")
                    self.directory_info[dir_path]["description"] = str(self.directory_info[dir_path]["description"])
                    
                if self.directory_info[dir_path]["description"]:
                    context_parts.append(f"所在目录描述: {self.directory_info[dir_path]['description']}")
            
            # 2. 添加父目录的描述（最多向上两级）
            parent_dir = os.path.dirname(dir_path)
            if parent_dir and parent_dir in self.directory_info and self.directory_info[parent_dir]["description"]:
                context_parts.append(f"父目录描述: {self.directory_info[parent_dir]['description']}")
                
                # 再上一级
                grandparent_dir = os.path.dirname(parent_dir)
                if grandparent_dir and grandparent_dir in self.directory_info and self.directory_info[grandparent_dir]["description"]:
                    context_parts.append(f"上级目录描述: {self.directory_info[grandparent_dir]['description']}")
            
            # 3. 添加同目录下其他代码文件的描述（最多3个）
            same_dir_files = [f for f in self.code_files 
                             if os.path.dirname(f["file_path"]) == dir_path 
                             and f["is_code_file"] 
                             and f != file_info]
            
            if same_dir_files:
                related_descs = [f"相关文件 {f['name']}: {f['description']}" 
                                for f in same_dir_files[:3]]
                context_parts.extend(related_descs)
            
            # 合并上下文
            if context_parts:
                enhanced_description += ". " + " ".join(context_parts)
            
            # 更新文件信息
            self.code_files[i]["enhanced_description"] = enhanced_description
            
            # 调试输出
            if i < 3:  # 只显示前3个增强描述作为示例
                print(f"\n增强描述示例 {i+1}:")
                print(f"文件: {file_info['file_path']}")
                print(f"原始描述: {file_info['description']}")
                print(f"增强描述: {enhanced_description}")
    
    async def find_matching_file(self, query: str) -> Tuple[Optional[str], float]:
        """
        使用 reranker 模型找到最匹配的代码文件，利用增强的文件描述
        
        Args:
            query: 用户查询
            
        Returns:
            Tuple[Optional[str], float]: 匹配的文件路径和分数，如果没有匹配则返回 (None, 0)
        """
        # 只考虑代码文件
        code_files = [f for f in self.code_files if f["is_code_file"]]
        
        if not code_files:
            print("警告: 没有代码文件信息可供匹配")
            return None, 0.0
        
        # 准备评分对，使用增强的描述
        file_descriptions = []
        for file_info in code_files:
            # 调试：检查描述是否为字符串
            enhanced_desc = file_info.get("enhanced_description", file_info["description"])
            if not isinstance(enhanced_desc, str):
                print(f"警告: 文件 {file_info['file_path']} 的增强描述不是字符串而是 {type(enhanced_desc)}: {enhanced_desc}")
                enhanced_desc = str(enhanced_desc)  # 转换为字符串
                
            file_descriptions.append(enhanced_desc)
        
        # 创建正确格式的评分对
        pairs = [[query if isinstance(query, str) else str(query), 
                desc if isinstance(desc, str) else str(desc)] 
                for desc in file_descriptions]        
        try:
            # 使用 reranker 评分
            scores = self.reranker.predict(pairs)
            
            # 获取前几名的匹配结果
            top_k = min(2, len(code_files))
            top_indices = np.argsort(scores)[-top_k:][::-1]
            
            print("\n查询:", query)
            print("前几名匹配结果:")
            for i, idx in enumerate(top_indices):
                print(f"{i+1}. {code_files[idx]['file_path']} (分数: {scores[idx]:.4f})")
                print(f"   描述: {code_files[idx]['description'][:100]}...")
            
            # 找到最高分及其索引
            max_score_idx = top_indices[0]
            max_score = scores[max_score_idx]
            
            # 检查分数是否超过阈值
            if max_score >= self.score_threshold:
                best_match = code_files[max_score_idx]
                print(f"\n最佳匹配: {best_match['file_path']} (分数: {max_score:.4f})")
                return best_match["file_path"], max_score
            else:
                print(f"\n没有找到符合阈值的匹配 (最高分数: {max_score:.4f})")
                return None, max_score
        except Exception as e:
            print("使用 reranker 模型评分时出错:")
            traceback.print_exc()  # 打印完整的错误堆栈信息
            return None, 0.0


async def select_code_file(instruction: str, code_retriever: CodeRetriever = None) -> Tuple[str, str]:
    """
    使用增强版的 reranker 模型选择最匹配的代码文件
    
    Args:
        instruction: 用户指令
        code_retriever: 代码检索器实例
        
    Returns:
        Tuple[str, str]: 引用代码和全局模型名称
    """
    # 如果未提供检索器，则创建一个新的
    if code_retriever is None:
        try:
            code_retriever = CodeRetriever(
                json_file_path = base_dir + "/AI4PDE/ai4pde_structure.json",
                reranker_model_path = "/mnt/sdb/bge/bge-reranker-large",
                score_threshold = 0.55
            )
        except Exception as e:
            print(f"初始化代码检索器时出错: {str(e)}")
            return "", ""
    
    # 使用增强版 reranker 查找匹配文件
    file_path, score = await code_retriever.find_matching_file(instruction)
    
    reference = ""
    global_models_name = ""
    
    if file_path:
        global_models_name = file_path
        #base_dir = '/home/suser/se42/ximu_science/responsible_programming/src'
        full_path = os.path.join(base_dir, file_path)
        
        if os.path.exists(full_path):
            try:
                with open(full_path, "r") as f:
                    reference = f.read()  # 用于参考
                print(f"已读取文件: {full_path}")
            except Exception as e:
                print(f"读取文件 {full_path} 时出错: {str(e)}")
        else:
            print(f"文件不存在: {full_path}")
    else:
        print("未找到匹配的代码文件")
    
    return reference, global_models_name

########################################
# 核心 Action
########################################

class Coding(Action):
    """
    负责让 LLM 根据用户需求生成可执行的代码，
    并在 LLM 判断需要执行时，尝试执行并反馈结果或错误，
    直至无报错或达到最大重试次数。
    集成了reranker模型用于代码文件检索。
    """
    name: str = "AI4PDE"
    desc: str = "基于AI算法的方程正向求解以及逆向计算"

    PROMPT_TEMPLATE: str = """
你是资深编程专家，擅长根据用户需求给出完整的可运行方案。参考代码为：{reference}
如果你认为无需运行代码，则请直接给出不含 ```python``` 代码块的答案；
如果你认为需要执行/验证代码，请在回答中仅编写一个包含完整代码的 ```python ...``` 代码块。
当你提供代码块时，我将尝试在Jupyter环境中执行它们，并把执行结果或错误信息再提供给你。
然后你可继续修正代码，直至无错误为止，或者对执行结果进行讨论总结。
如果要使用matplotlib, 请在画图时使用英文, 因为matplotlib不支持中文。
请你注意, 你生成的代码只有60秒的执行时间, 请注意算力资源使用。

请使用中文进行解释和注释。用户需求为：{instruction}
请开始你的回答。
    """

    PROMPT_TEMPLATE_FILE: str = """
你是资深编程专家，擅长根据用户需求给出完整的可运行方案。参考代码为：{reference}
如果你认为无需运行代码，则请直接给出不含 ```python``` 代码块的答案；
如果你认为需要执行/验证代码，请在回答中仅编写一个包含完整代码的 ```python ...``` 代码块。
当你提供代码块时，我将尝试在Jupyter环境中执行它们，并把执行结果或错误信息再提供给你。
然后你可继续修正代码，直至无错误为止，或者对执行结果进行讨论总结。
如果要使用matplotlib, 请在画图时使用英文, 因为matplotlib不支持中文
请你注意, 你生成的代码只有60秒的执行时间, 请注意算力资源使用。

用户上传的文件路径为{file_path}, 文件名为{file_names}
请使用中文进行解释和注释。用户需求为：{instruction}
请开始你的回答。
    """

    ERROR_PROMPT_TEMPLATE: str = """
代码执行出现错误：
{error_info}

请对之前生成的代码进行修正，保证最终代码能够正确运行，并给出新的完整方案
（如果仍需执行，请务必使用 ```python ...``` 代码块）。
如果要使用matplotlib, 请在画图时使用英文, 因为matplotlib不支持中文
    """

    SUCCESS_PROMPT_TEMPLATE: str = """
你的代码已成功执行，输出结果如下：
{exec_output}

请根据该结果继续回答用户，或进行总结和分析。
    """

    PROMPT_TEMPLATE_SELECT: str  = """
    你是代码信息提取员。请结合用户的需求{instruction}，分析出关键问题, 根据代码结构信息{code_tree}，查看可以对应到哪个代码文件。如果可以对应到，仅回复一个最匹配问题的py文件名，不能包含换行符'\n', 例如以下示例：

    PINN
    ├─ Thermodynamics                        # 热力学相关问题模块，研究卫星热传递和大气热力学问题。
    │  ├─ Satellite_Heat_Transfer            # 卫星热传递模拟，包括稳态和瞬态情况。
    │  │  ├─ Pinnsformer_withsun             # 结合太阳辐射因素的Pinnsformer模型。
    │  │  │  ├─ Pinnsformer.py              # Pinnsformer模型定义，用于稳态热传导问题模拟，包含太阳辐射作为外部热源。
    │  │  │  ├─ train.py                    # 训练Pinnsformer模型，优化网络参数以匹配物理方程解。
    │  │  │  ├─ utils.py                    # 通用工具函数，包括数据预处理和结果可视化。
    
    用户问题: 利用transformer模型模拟卫星热力学仿真训练代码
    仅回复py结尾的包含所有上层路径的文件名：PINN/Thermodynamics/Satellite_Heat_Transfer/Pinnsformer_withsun/Pinnsformer.py
    ###

    如果没有找到，只回复'无'

    请给出你的匹配文件名称：
    """

    def _process_output_for_llm(self, output: str) -> str:
        """
        处理输出内容，将所有base64图片数据替换为占位符，避免上下文过长
        """
        # 如果输出是纯图片数据
        if output.startswith('data:image'):
            return "[图片输出已生成]"
        
        # 在文本中查找并替换所有base64图片数据
        base64_pattern = re.compile(r'(data:image\/[^;]+;base64,[a-zA-Z0-9+/=]{100,})')
        return base64_pattern.sub("[图片输出已生成]", output)

    async def run(self, instruction: str, *args):
        websocket = args[0]
        user_name, taskid, file_names = args[1], args[2], args[3]
        # print(f"args: {args}")
        #save_path = "upload/{}/{}".format(user_name, taskid)
        #if not os.path.exists(save_path):
        #    os.makedirs(save_path)
        
        # 通过云存储把指定文件下载到本地
        # download_to_file("science-backend", "upload/{}".format(user_name), save_path, file_names)
        
        config = load_config("config/config.yaml")
        llm = SeLLM(base_url=config["base_url_1"], api_key=config["api_key"])
        global_models_name = ""
        tree_txt = "tools/TREE.txt"
        with open(tree_txt, "r") as f:
            code_tree =  f.read() #用于参考

        results=""
        prompt = self.PROMPT_TEMPLATE_SELECT.format(code_tree=code_tree, instruction=instruction)
        message = [self.llm._default_system_msg()]
        message.append(self.llm._user_msg(prompt))
        response = await llm.acompletion_text(message,temperature=0.7,timeout=8)
        collected_messages=[]
        async for chunk in response:
            chunk_message = chunk.choices[0].delta.content or "" if chunk.choices else ""  # extract the message
            collected_messages.append(chunk_message)
        global_models_name = "".join(collected_messages)

        file_path = source_path + '/src/{}'.format(global_models_name)
        print("\n* file_path为：{}\n\n".format(file_path))
        if os.path.exists(file_path):
            with open(file_path, "r") as f:
                reference =  f.read() #用于参考  
        else:
            reference = "用基于pytorch的PINN算法来实现AI求解正问题或者逆问题"
        '''
        # 使用reranker模型进行代码文件检索
        try:
            # 初始化代码检索器
            code_retriever = CodeRetriever(
                reranker_model_path="/mnt/sdb/bge/bge-reranker-large",
                score_threshold=0.55  # 设置一个适当的分数阈值
            )
            
            # 使用检索器查找最匹配的代码文件
            reference, global_models_name = await select_code_file(instruction, code_retriever)
            
            if not global_models_name:
                await websocket.send_text("\n\n未找到与用户需求匹配的代码文件，将使用通用模式回答问题。\n\n")
                reference = ""
        except Exception as e:
            await websocket.send_text(f"\n\n代码检索时出现错误: {str(e)}，将使用通用模式回答问题。\n\n")
            reference = ""
            global_models_name = ""
        '''
        

        if len(file_names) == 0:
            prompt = self.PROMPT_TEMPLATE.format(instruction=instruction, reference=reference)
        else:
            file_name = file_names[0]
            # file_path = os.path.join("upload", user_name, taskid, file_name)
            # if not os.path.exists(file_path):
            #     await websocket.send_text("没找到文件{},请检查是否上传成功！".format(file_name))
            #     print("文件不存在！请检查是否上传成功！")
            #     await websocket.close()
            prompt = self.PROMPT_TEMPLATE_FILE.format(instruction=instruction, reference=reference, file_path="upload/", file_names=file_names)

        print(f"prompt:{prompt}")
        
        messages = [
            llm._default_system_msg(),
            llm._user_msg(prompt)
        ]

        response_text = await self._stream_llm_response(llm, messages, websocket)

        attempt = 0
        max_attempts = 2
        execution_complete = False  # 添加标志来追踪执行状态
        
        while attempt < max_attempts and not execution_complete:  # 修改循环条件
            code_snippets = extract_all_python_codes(response_text)
            if not code_snippets:
                execution_complete = True  # 如果没有代码需要执行，标记为完成
                break

            await websocket.send_text("\n\n(๑˘ ˘๑) 本AI将会尝试运行{}次，第{}次尝试:\n\n".format(max_attempts, attempt+1))
            accumulated_stdout = ""
            error_occurred = False
            
            for idx, code_snippet in enumerate(code_snippets, start=1):
                print('code_snippets:{}'.format(code_snippets))
                stdout, stderr = await run_code(code_snippet, user_name, websocket)

                if stderr.strip():
                    error_prompt = self.ERROR_PROMPT_TEMPLATE.format(error_info=stderr)
                    messages = [
                        llm._default_system_msg(),
                        llm._assistant_msg(response_text),
                        llm._user_msg(error_prompt)
                    ]
                    response_text = await self._stream_llm_response(llm, messages, websocket)
                    attempt += 1
                    error_occurred = True
                    break

                if stdout:
                    # 这里不需要额外发送到websocket，因为run_code函数已经处理了
                    accumulated_stdout += stdout + "\n"
                    if error_occurred:
                        continue

            # 处理最终输出，发送给LLM
                if accumulated_stdout.strip():
                    # 过滤base64数据
                    filtered_stdout = self._process_output_for_llm(accumulated_stdout.strip())
                    success_prompt = self.SUCCESS_PROMPT_TEMPLATE.format(
                        exec_output=filtered_stdout
                    )
                messages = [
                    llm._default_system_msg(),
                    llm._assistant_msg(response_text),
                    llm._user_msg(success_prompt)
                ]
                try:
                    response_text = await self._stream_llm_response(llm, messages, websocket)
                    execution_complete = True  # 标记执行完成
                except Exception as e:
                    logging.error(f"Error in LLM response: {str(e)}")
                    if "maximum context length" in str(e):
                        # 如果是上下文长度问题，尝试只保留最后的代码和结果
                        simplified_response = response_text.split("```python")[-1]
                        if "```" in simplified_response:
                            simplified_response = "```python" + simplified_response
                        
                        messages = [
                            llm._default_system_msg(),
                            llm._assistant_msg(simplified_response),
                            llm._user_msg("执行成功，请总结一下结果。")
                        ]
                        try:
                            response_text = await self._stream_llm_response(llm, messages, websocket)
                            execution_complete = True  # 标记执行完成
                        except Exception as e2:
                            logging.error(f"Error in simplified LLM response: {str(e2)}")
                            await websocket.send_text("\n\n代码执行成功！由于结果较大，请直接查看上方输出。\n")
                            execution_complete = True  # 即使出错也标记为完成
                    else:
                        await websocket.send_text("\n\n代码执行成功！\n")
                        execution_complete = True  # 标记执行完成
            else:
                execution_complete = True  # 如果没有输出也标记为完成

        return response_text

    async def _stream_llm_response(self, llm, messages, websocket=None) -> str:
        collected_chunks = []
        
        retries = 0
        max_retries=3
        stream_res=None
        import openai
        while retries < max_retries:
            try:
                stream_res = await llm.acompletion_text(messages, temperature=0.7, timeout=10)
                break
            except openai.APITimeoutError:
                retries += 1
                print(f"Request timed out. Retrying... ({retries}/{max_retries})")
                await asyncio.sleep(0.5)  # 等待0.5秒后重试

        async for chunk in stream_res:
            if chunk.choices and chunk.choices[0].delta:
                chunk_msg = chunk.choices[0].delta.content or ""
            else:
                chunk_msg = ""

            if chunk_msg:
                collected_chunks.append(chunk_msg)
                if websocket:
                    await websocket.send_text(chunk_msg)

        return "".join(collected_chunks)

########################################
# 定义角色
########################################

class XIMU_AI4PDE(Role):
    name: str = "硒钼AI4PDE"
    profile: str = "基于AI算法模型求解各类ODE/PDE方程"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._watch([UserRequirement])
        self.set_actions([Coding])

########################################
# 主流程
########################################

async def start(user_request: str, n_round: int = 2):
    team = Team()
    team.hire([XIMU_AI4PDE()])
    requirement = UserRequirement(instruction=user_request)
    team.add_req(requirement)
    await team.run(n_round=n_round)

async def main():
    while True:
        user_input = input("\n\n老板，您好（输入 '结束' 或 'exit' 退出）：")
        if user_input in ("结束", "exit"):
            print("再见！")
            break
        else:
            await start(user_input, n_round=3)

if __name__ == "__main__":
    asyncio.run(main())
